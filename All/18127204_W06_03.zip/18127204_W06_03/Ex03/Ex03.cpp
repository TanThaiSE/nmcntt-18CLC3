///ID: 18127204
///Name: Thai Nhat Tan
///Ex03: Ve hinh chu nhat mxn
#include<stdio.h>
#include<math.h>
int main()
{
	int m, n;
	scanf_s("%d%d", &m, &n);
	for (int i = 1; i <= n - 1; i++)
		printf("*");
		printf("*\n");
	for (int i = 1; i <= m - 2; i++)
	{
		printf("*");
		for (int j = 1; j <= n - 2; j++)
		printf(" ");
		printf("*\n");
	}
	for (int i = 1; i <= n; i++)
		printf("*");
		printf("\n");
	return 0;
}