///ID: 18127204
///Name: Thai Nhat Tan
///Ex01: Tien di taxi
#include<stdio.h>
#include<math.h>
#define km1 22000
#define km2 14500
#define km3 11600
#define km4 9000
int main()
{
	int x, s1, s2, s3, s4;
	printf("Nhap vao so km: "); scanf_s("%d", &x);
	if (x > 80)
	{
		s1 = x*km4;
		printf("Tong so tien phai tra la:%d dong", s1);
	}
	else
	{
		if (x > 30)
		{
			s2 = km1 * 1 + km2 * 29 + (x - 30)*km3;
			printf("Tong so tien phai tra la:%d dong", s2);
		}
		else
		{
			if (x >= 2)
			{
				s3 = km1 * 1 + km2 * (x - 1);
				printf("Tong so tien phai tra la:%d dong", s3);
			}
			else
			{
				if (x > 0)
					s4 = km1 * 1;
					printf("Tong so tien phai tra la:%d dong", s4);
			}
		}
	}
	return 0;
}
	