///ID: 18127204
///Name: Thai Nhat Tan
///Ex02: HIV
#include<stdio.h>
#include<math.h>
int main()
{
	int n;
	float x;
	int dem = 0;
	scanf_s("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		scanf_s("%f", &x);
		if (x > 0.5)
		{
			dem++;
		}
	}
	printf("%d", dem);
	return 0;
}