#ifndef _HAM_H
#define _HAM_H
struct Diem
{
	float x, y;
};
void nhapdiem(Diem &a);
void xuatdiem(Diem a);
float euclid(Diem a, Diem b);
float manhattan(Diem a, Diem b);
struct Tamgiac
{
	Diem A, B, C;
};
void nhaptamgiac(Tamgiac &a);
void xuattamgiac(Tamgiac a);
float chuvi(Tamgiac a);
float dientich(Tamgiac a);
int kiemtratamgiac(Tamgiac a);
int loaitamgiac(Tamgiac a);
Diem trongtam(Tamgiac a);
void nhapmang(Tamgiac a[], int &n);
void xuatmang(Tamgiac a[], int n);
void xuatmang(Tamgiac a[], int n);
void demtamgiac(Tamgiac a[], int n);
int chuvinhonhat(Tamgiac a[], int n);
int dientichlonnhat(Tamgiac a[], int n);
float tongdientich(Tamgiac a[], int n);
void sapxepgiamdan(Tamgiac a[], int n);
void sapxeptangdan(Tamgiac a[], int n);
#endif