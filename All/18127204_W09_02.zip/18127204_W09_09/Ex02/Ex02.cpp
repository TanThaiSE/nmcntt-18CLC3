///ID: 18127204
///Name: Thai Nhat Tan
///Ex02: Struct tam giac
#include"Ham.h"
#include<iostream>
#include<cmath>
#include<stdio.h>
using namespace std;
int main()
{
	Diem a, b, f;
	float c, d, x, y, z;
	Tamgiac e, g[1000];
	int n, m, k;
	cout << "Nhap diem thu 1:\n";	nhapdiem(a); xuatdiem(a);	
	cout << "\nNhap diem thu 2:\n";	nhapdiem(b); xuatdiem(b);
	c = euclid(a, b);
	cout << "\nKhoang cach Euclidean 2 diem la:" << c << endl;
	d = manhattan(a, b);
	cout << "Khoang cach Manhattan 2 diem la:" << d << endl;
	nhaptamgiac(e); xuattamgiac(e);
	x = chuvi(e);
	cout << "\nChu vi tam giac la:" << x << endl;
	y = dientich(e);
	cout << "\nDien tich tam giac la:" << y << endl;
	if (kiemtratamgiac(e) == 1)
	{
		cout << "Tao thanh tam giac" << endl;
	}
	else
	{
		cout << "Khong tao thanh tam giac" << endl;
	}
	if (loaitamgiac(e) == 1)
	{
		printf("La tam giac deu\n");
	}
	else if (loaitamgiac(e) == 2)
	{
		printf("La tam giac vuong can\n");
	}
	else if (loaitamgiac(e) == 3)
	{
		printf("La tam giac can\n");
	}
	else if (loaitamgiac(e) == 4)
	{
		printf("La tam giac vuong\n");
	}
	else if (loaitamgiac(e) == 5)
	{
		printf("La tam giac thuong\n");
	}	
	else if (loaitamgiac(e) == 6)
	{
		printf("Khong lap thanh tam giac\n");
	}
	f = trongtam(e);
	cout << "Toa do trong tam tam giac la" << endl;
	xuatdiem(f);
	nhapmang(g, n);
	xuatmang(g, n);
	demtamgiac(g, n);
	m = chuvinhonhat(g, n);
	k = dientichlonnhat(g, n);
	cout << "Tam giac co chu vi nho nhat la:a[" << m << "]" << endl;
	cout << "Tam giac co dien tich lon nhat la:a[" << k << "]" << endl;
	z = tongdientich(g, n);
	cout << "Tong dien tich tam giac la:" << z << endl;
	cout << "Tam giac giam dan theo chu vi" << endl;
	sapxepgiamdan(g, n);
	cout << "Tam giac tang dan theo dien tich" << endl;
	sapxeptangdan(g, n);
	return 0;
}