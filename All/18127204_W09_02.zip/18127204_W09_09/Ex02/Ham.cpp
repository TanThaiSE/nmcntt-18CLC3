#include<iostream>
#include<cmath>
#include"Ham.h"
using namespace std;
void nhapdiem(Diem &a)
{
	cout << "Hoanh do:";	cin >> a.x;
	cout << "Tung do:";		cin >> a.y;
}
void xuatdiem(Diem a)
{
	cout << "Diem vua nhap la(" << a.x << "," << a.y << ")" << endl;
}
float euclid(Diem a, Diem b)
{
	float c, d, e;
	c = pow((a.x - b.x), 2);
	d = pow((a.y - b.y), 2);
	e = (float)sqrt(c + d);
	return e;
}
float manhattan(Diem a, Diem b)
{
	float d;
	d = fabs(a.x - b.x) + fabs(a.y - b.y);
	return d;
}
void nhaptamgiac(Tamgiac &a)
{
	cout << "Nhap toa do Diem A:\n";
	nhapdiem(a.A);
	cout << "Nhap toa do Diem B:\n";
	nhapdiem(a.B);	
	cout << "Nhap toa do Diem C:\n";
	nhapdiem(a.C);	
}
void xuattamgiac(Tamgiac a)
{
	xuatdiem(a.A);
	xuatdiem(a.B);
	xuatdiem(a.C);
}
float chuvi(Tamgiac a)
{
	float s, AB, BC, CA;
	AB = euclid(a.A, a.B); //AB
	BC = euclid(a.B, a.C);//BC
	CA = euclid(a.C, a.A);//CA
	s = AB + BC + CA;
	return s;
}
float dientich(Tamgiac a)
{
	float s, AB, BC, CA, p;
	AB = euclid(a.A, a.B); //AB
	BC = euclid(a.B, a.C);//BC
	CA = euclid(a.C, a.A);//CA
	p = (AB + BC + CA)*1.0 / 2;
	s = (float)sqrt(p*(p - AB)*(p - BC)*(p - CA));
	return s;
}
int kiemtratamgiac(Tamgiac a)
{
	float AB, BC, CA;
	AB = euclid(a.A, a.B); //AB
	BC = euclid(a.B, a.C);//BC
	CA = euclid(a.C, a.A);//CA
	if ((AB + BC > CA) && (BC + CA > AB) && (AB + CA > BC) && (fabs(AB - BC) < CA) && (fabs(BC - CA) < AB) && (fabs(AB - CA) < BC))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int loaitamgiac(Tamgiac a)
{
	int d;
	float AB, BC, CA;
	AB = euclid(a.A, a.B); //AB
	BC = euclid(a.B, a.C);//BC
	CA = euclid(a.C, a.A);//CA
	if (kiemtratamgiac(a) == 1)
	{
		if ((AB == BC) && (BC == CA) && (AB == CA))
		{			
			d = 1;
		}
		else if ((AB*AB == BC * BC + CA * CA) && (BC == CA) || (BC*BC == AB * AB + CA * CA) && (AB == CA) || (CA*CA == BC * BC + AB * AB) && (BC == AB))
		{
			d = 2;
		}		
		else if ((AB*AB != BC * BC + CA * CA) && (BC == CA) || (BC*BC != AB * AB + CA * CA) && (AB == CA) || (CA*CA != BC * BC + AB * AB) && (BC == AB))
		{
			d = 3;
		}
		else if ((AB*AB == BC * BC + CA * CA) || (BC*BC == AB * AB + CA * CA) || (CA*CA == BC * BC + AB * AB))
		{
			d = 4;
		}
		else
		{			
			d = 5;
		}			
	}
	else
	{
		d = 6;
	}
	return d;
}
Diem trongtam(Tamgiac a)
{
		Diem kq;
		kq.x = (a.A.x + a.B.x + a.C.x)*1.0 / 3;
		kq.y = (a.A.y + a.B.y + a.C.y)*1.0 / 3;	
		return kq;
} 
void nhapmang(Tamgiac a[], int &n)
{
	cout << "Nhap n:";	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "Nhap a[" << i << "]=" << endl;
		nhaptamgiac(a[i]);
	}
}
void xuatmang(Tamgiac a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << "a[" << i << "]=" << endl;
		xuattamgiac(a[i]);
	}
}
void demtamgiac(Tamgiac a[], int n)
{
	int d = 0, vc = 0, c = 0, v = 0, t = 0;
	for (int i = 0; i < n; i++)
	{
		if (kiemtratamgiac(a[i]) == 1)
		{
			if (loaitamgiac(a[i]) == 1)
			{
				d++;
			}
			else if (loaitamgiac(a[i]) == 2)
			{
				vc++;
			}
			else if (loaitamgiac(a[i]) == 3)
			{
				c++;
			}
			else if (loaitamgiac(a[i]) == 4)
			{
				v++;
			}
			else if (loaitamgiac(a[i]) == 5)
			{
				t++;
			}
		}
	}
	cout << "So tam giac deu la:" << d << "" << endl;
	cout << "So tam giac vuong can la:" << vc << "" << endl;
	cout << "So tam giac can la:" << c << "" << endl;
	cout << "So tam giac vuong la:" << v << "" << endl;
	cout << "So tam giac thuong la:" << t << "" << endl;
}
int chuvinhonhat(Tamgiac a[], int n)
{
	float min = chuvi(a[0]);
	int vitri =0;
	for (int i = 0; i < n; i++)
	{
		if (chuvi(a[i]) < min)
		{
			min = chuvi(a[i]);
			vitri = i;
		}
	}
	return vitri;
}
int dientichlonnhat(Tamgiac a[], int n)
{
	float max = dientich(a[0]);
	int vitri = 0;
	for (int i = 0; i < n; i++)
	{
		if (dientich(a[i]) > max)
		{
			max = dientich(a[i]);
			vitri = i;
		}
	}
	return vitri;
}
float tongdientich(Tamgiac a[], int n)
{
	float s = 0;
	for (int i = 0; i < n; i++)
	{
		s = s + dientich(a[i]);
	}
	return s;
}
void sapxepgiamdan(Tamgiac a[], int n)
{
	Tamgiac temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = i+1; j < n; j++)
		{
			if (chuvi(a[i]) > chuvi(a[j]))
			{
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
	for (int i = 0; i < n; i++)
	{
		xuattamgiac(a[i]);
	}
}
void sapxeptangdan(Tamgiac a[], int n)
{
	Tamgiac temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (dientich(a[i]) < dientich(a[j]))
			{
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
	for (int i = 0; i < n; i++)
	{
		xuattamgiac(a[i]);
	}
}

