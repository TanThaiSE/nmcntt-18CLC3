#ifndef _HAM_H_
#define _HAM_H_
struct PhanSo
{
	int tu, mau;
};
void nhap(PhanSo &p);
void xuat(PhanSo p);
PhanSo cong(PhanSo p1, PhanSo p2);
PhanSo tru(PhanSo p1, PhanSo p2);
PhanSo nhan(PhanSo p1, PhanSo p2);
PhanSo chia(PhanSo p1, PhanSo p2);
int sosanh(PhanSo p1, PhanSo p2);
int xetdau(PhanSo p);
int uocchunglonnhat(int a, int b);
void rutgon(PhanSo p);
void nhapmang(PhanSo a[], int &n);
void xuatmang(PhanSo a[], int n);
PhanSo nhonhat(PhanSo a[], int n);
PhanSo lonnhat(PhanSo a[], int n);
PhanSo soamdautien(PhanSo a[], int n);
PhanSo tong(PhanSo a[], int n);
int phansokhong(PhanSo a[], int n);
void lietke(PhanSo a[], int n);
void sapxep(PhanSo a[], int n);
void sapxepphanso(PhanSo a[], int n);
void sapxep(PhanSo a[], int n);
#endif 
