#include<iostream>
#include"Ham.h"
#include<cmath>
using namespace std;
void nhap(PhanSo &p)
{
	cout << "Nhap tu: ";
	cin >> p.tu;
	cout << "Nhap mau: ";
	cin >> p.mau;
}
void xuat(PhanSo p)
{
	if (p.mau < 0)
	{
		p.tu = -p.tu;
		p.mau = -p.mau;
	}
		cout << p.tu << "/" << p.mau << endl;
}
PhanSo cong(PhanSo p1, PhanSo p2)
{
	PhanSo kq;
	kq.tu = p1.tu * p2.mau + p1.mau * p2.tu;
	kq.mau = p1.mau * p2.mau;
	return kq;
}
PhanSo tru(PhanSo p1, PhanSo p2)
{
	PhanSo kq;
	kq.tu = p1.tu*p2.mau - p2.tu*p1.mau;
	kq.mau = p1.mau*p2.mau;
	return kq;
}
PhanSo nhan(PhanSo p1, PhanSo p2)
{
	PhanSo kq;
	kq.tu = p1.tu*p2.tu;
	kq.mau = p1.mau*p2.mau;
	return kq;
}
PhanSo chia(PhanSo p1, PhanSo p2)
{
	PhanSo kq;
	kq.tu = p1.tu*p2.mau;
	kq.mau = p1.mau*p2.tu;
	return kq;
}
int sosanh(PhanSo p1, PhanSo p2)
{
	int s;
	if ((p1.tu*p2.mau == p2.tu*p1.mau) && (p1.mau*p2.mau != 0))
	{
		s = 0;
	}
	else if ((p1.tu*p2.mau > p2.tu*p1.mau) && (p1.mau*p2.mau != 0))
	{
		s = 1;
	}
	else if ((p1.tu*p2.mau < p2.tu*p1.mau) && (p1.mau*p2.mau != 0))
	{
		s = -1;
	}
	return s;

}
int xetdau(PhanSo p)
{
	int s;
	if ((p.tu*p.mau) > 0 && (p.mau != 0))
	{
		s = 1;
	}
	else if ((p.tu*p.mau) < 0 && (p.mau != 0))
	{
		s = -1;
	}
	else if (p.tu*p.mau == 0 && (p.mau != 0))
	{
		s = 0;
	}
	return s;
}
int uocchunglonnhat(int a, int b)
{
	a = fabs(a);
	b = fabs(b);
	while (a != b)
	{
		if (a > b)
		{
			a = a - b;
		}
		else
		{
			b = b - a;
		}
	}
	return a;
}
void rutgon(PhanSo p)
{
	int m = uocchunglonnhat(p.tu, p.mau);
	p.tu = p.tu / m;
	p.mau = p.mau / m;
	cout << p.tu << "/" << p.mau;
}
void nhapmang(PhanSo a[], int &n)
{
	cout << "\nNhap n:";	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "a[" << i << "]=" << endl;
		nhap(a[i]);
	}
}
void xuatmang(PhanSo a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		xuat(a[i]);
	}
}
PhanSo nhonhat(PhanSo a[], int n)
{
	PhanSo min;
	min = a[0];
	for (int i = 0; i < n; i++)
	{
		if (sosanh(a[i], min) == -1)
		{
			min = a[i];
		}
	}
	return min;
}
PhanSo lonnhat(PhanSo a[], int n)
{
	PhanSo max;
	max = a[0];
	for (int i = 0; i < n; i++)
	{
		if (sosanh(a[i], max) == 1)
		{
			max = a[i];
		}
	}
	return max;
}
PhanSo soamdautien(PhanSo a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		if (xetdau(a[i]) == -1)
		{
			return a[i];
			break;
		}
	}
}
PhanSo tong(PhanSo a[], int n)
{
	PhanSo s = a[0];
	for (int i = 1; i < n; i++)
	{
			s = cong(a[i], s);
	}
	return s;
}
int phansokhong(PhanSo a[], int n)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
	{
		if (xetdau(a[i]) == 0)
		{
			dem++;
		}
	}
	return dem;
}
void lietke(PhanSo a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		if (xetdau(a[i]) == 1)
		{
			xuat(a[i]);
		}
	}
}
void sapxepphanso(PhanSo a[], int n)
{
	PhanSo temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (sosanh(a[i], a[j]) == 1)
			{
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
	for (int i = 0; i < n; i++)
	{
		xuat(a[i]);
	}
}
void sapxep(PhanSo a[], int n)
{
	PhanSo temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (xetdau(a[i]) == -1 && xetdau(a[j]) == -1)
			{
				if (sosanh(a[i], a[j]) == -1)
				{
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
	}
	for (int i = 0; i < n; i++)
	{
		xuat(a[i]);
	}
}

