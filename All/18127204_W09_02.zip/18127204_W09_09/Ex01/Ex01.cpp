///ID: 18127204
///Name: Thai Nhat Tan
///Ex01: Struct phan so
#include"Ham.h"
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	PhanSo p1, p2, a, b, c, d, f, g, h, q,t;
	PhanSo e[1000];
	int n, r;
	cout << "Nhap phan so 1:" << endl;
	nhap(p1);
	cout << "Phan so thu 1 la:";
	xuat(p1);
	cout << "\nNhap phan so 2:" << endl;
	nhap(p2);
	cout << "Phan so thu 2 la:" << endl;
	xuat(p2);
	a = cong(p1, p2);
	cout << "\nTong hai phan so la";
	xuat(a);
	b = tru(p1, p2);
	cout << "\nHieu hai phan so la";
	xuat(b);
	c = nhan(p1, p2);
	cout << "\nTich hai phan so la";
	xuat(c);
	cout << "\nThuong hai phan so la";
	d = chia(p1, p2);
	xuat(d);
	if (sosanh(p1, p2) == 0)
	{
		printf("\nHai phan so bang nhau");
	}
	else if (sosanh(p1, p2) == 1)
	{
		printf("\nPhan so thu 1 lon hon phan so thu 2");
	}
	else if (sosanh(p1, p2) == -1)
	{
		printf("\nPhan so thu 1 nho hon phan so thu 2");
	}
	if (xetdau(p1) == 1)
	{
		printf("\nPhan so thu 1 lon hon 0");
	}
	else if (xetdau(p1) == -1)
	{
		printf("\nPhan so thu 1 nho hon 0");
	}
	else if (xetdau(p1) == 0)
	{
		printf("\nPhan so thu 1 bang hon 0");
	}
	if (xetdau(p2) == 1)
	{
		printf("\nPhan so thu 2 lon hon 0");
	}
	else if (xetdau(p2) == -1)
	{
		printf("\nPhan so thu 2 nho hon 0");
	}
	else if (xetdau(p2) == 0)
	{
		printf("\nPhan so thu 2 bang hon 0");
	}
	printf("\nPhan so thu 1 da duoc rut gon la:");
	rutgon(p1);
	printf("\nPhan so thu 2 da duoc rut gon la:");
	rutgon(p2);
	nhapmang(e, n);
	xuatmang(e, n); 
	f = nhonhat(e, n);
	cout << "Phan so nho nhat la:";
	xuat(f);
	g = lonnhat(e, n);
	cout << "Phan so lon nhat la:";
	xuat(g);
	h = soamdautien(e, n);
	cout << "Phan so am dau tien la:";
	xuat(h);
	q = tong(e, n);
	cout << "Tong cac phan so la:";
	xuat(q);
	r = phansokhong(e, n);
	cout << "Cac phan so khong:" << r;
	cout << "\nCac phan so duong la:";
	lietke(e, n);
	cout << "\nCac phan so theo thu tu tang dan:";
	sapxepphanso(e, n);
	cout << "\nCac phan so am giam dan,phan so khong va so duong tang dan la:";
	sapxep(e, n);
	return 0;
}