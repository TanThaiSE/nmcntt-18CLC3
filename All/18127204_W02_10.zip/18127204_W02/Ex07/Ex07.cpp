///ID: 18127204
///Name: Thai Nhat Tan
///Ex07: perimeter and triangle area
#include<stdio.h>
#include<math.h>
int main()
{
	float a, b, c, p, s;
	printf("Enter a=");
	scanf_s("%f", &a);
	printf("Enter b=");
	scanf_s("%f", &b);
	printf("Enter c=");
	scanf_s("%f", &c);
	p = ((a + b + c) / 2);
	s = sqrt(p * (p - a)*(p - b)*(p - c));
	if ((a > 0) && (b > 0) && (c > 0) && (fabs(a-b) < c) && (fabs(b-c) < a) && (fabs(c-a) < b) && (a+b>c) && (b+c>a) && (c+a>b))
	printf("Perimerter: %0.2f\n", 2 * p);
	if ((a > 0) && (b > 0) && (c > 0) && (fabs(a-b) < c) && (fabs(b-c) < a) && (fabs(c-a) < b) && (a+b>c) && (b+c>a) && (c+a>b))
	printf("Area: %0.2f", s);
	return 0;
}