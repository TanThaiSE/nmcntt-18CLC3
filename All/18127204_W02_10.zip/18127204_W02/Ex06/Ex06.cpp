///ID: 18127204
///Name: Thai Nhat Tan
///Ex06: total payment
#include<stdio.h>;
int main()
{
	int a, b, c;
	printf("amount:");
	scanf_s("%d", &a);
	printf("unit price:");
	scanf_s("%d", &b);
	c = a * b*(1 + 0.1);
	printf("money to pay:%d",c);
	return 0;
}
