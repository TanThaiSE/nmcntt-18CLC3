///ID: 18127204
///Name: Thai Nhat Tan
///Ex04: calculate the number of KWh used
#include<stdio.h>
int main()
{
	int a, b, c;
	printf("last month's electricity number:");
	scanf_s("%d", &a);
	printf("current electricity meter:");
	scanf_s("%d", &b);
	c = b - a;	
	printf("consuming KWh=%d-%d=%d", b, a, c);
	return 0;
}