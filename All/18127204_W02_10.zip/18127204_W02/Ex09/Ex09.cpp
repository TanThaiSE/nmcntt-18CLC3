///ID: 18127204
///Name: Thai Nhat Tan
///Ex09: Calculates y1 and y2
#include<stdio.h>
#include<math.h>
#define pi 3.141592654
int main()
{
	float x, y1, y2;
	printf("Enter x=");
	scanf_s("%f", &x);
	y1 = 4 * (x*x + 10 * x*(sqrt(x)) + 3 * x + 1);
	y2 = (sin(pi*x*x) + sqrt(x*x + 1)) / (exp(2 * x) + cos(pi / 4 * x));
	printf("y1=%0.2f\n", y1);
	printf("y2=%0.2f", y2);
	return 0;
}