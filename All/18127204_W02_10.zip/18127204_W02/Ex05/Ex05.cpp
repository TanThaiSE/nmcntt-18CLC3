///ID: 18127204
///Name: Thai Nhat Tan
///Ex05: Calculate the age of the person
#include<stdio.h>
#define namhientai 2018
int main()
{
	int a, b;
	printf("Enter the year of birth:");
	scanf_s("%d", &a);
	b = namhientai - a;
	printf("Your age is: %d",b );
	return 0;
}
