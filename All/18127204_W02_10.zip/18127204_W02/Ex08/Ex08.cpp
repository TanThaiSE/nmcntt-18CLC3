///ID: 18127204
///Name: Thai Nhat Tan
///Ex08: perimeter and circle area
#include<stdio.h>
#define pi 3.14
int main()
{
	float a, b, c, s;
	printf("Enter radius:");
	scanf_s("%f", &a);
	c = 2 * pi * a;
	s = pi * a * a;
	printf("perimeter: %0.2f\n", c);
	printf("Area: %0.2f", s);
	return 0;
}