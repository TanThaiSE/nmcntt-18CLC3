///ID: 18127204
///Name: Thai Nhat Tan
///Ex03: sin,cos,tan,cot
#include<stdio.h>
#include<math.h>
#define pi 3.141592654
int main()
{
	float x, a, b, c, d;
	printf("Enter number:");
	scanf_s("%f", &x);
	a = sin((x*pi)/180);
	b = cos((x*pi)/180);
	c = tan((x*pi)/180);
	d = 1 / c;
	printf("sin(%f) = %0.2f\n", x, a);
	printf("cos(%f) = %0.2f\n", x, b);
	printf("tan(%f) = %0.2f\n", x, c);
	printf("cot(%f) = %0.2f\n", x, d);
	return 0;
}
