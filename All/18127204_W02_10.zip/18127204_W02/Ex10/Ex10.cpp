///ID: 18127204
///Name: Thai Nhat Tan
///Ex10: so nut cua bien so
#include<stdio.h>
int main()
{
	int a, b = 0, c;
	printf("Nhap bien so:");
	scanf_s("%d", &a);
	while (a > 0)
	{
		c = a % 10;
		b = b + c;
		a = a / 10;
	}
	b = b % 10;
	printf("so nut la: %d", b);
	return 0;
}