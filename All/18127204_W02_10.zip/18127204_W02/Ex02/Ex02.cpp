///ID: 18127204
///Name: Thai Nhat Tan
///Ex02: add,sub,mul,div
#include<stdio.h>
int main()
{
	int a, b, add, sub, mul;
	float div;
	printf("Enter number a=");
	scanf_s("%d", &a);
	printf("Enter number b=");
	scanf_s("%d", &b);
	
	add = a + b;
	sub = a - b;
	mul = a * b;
	div = 1.0* a / b;
	printf("%d + %d =%d\n",a,b,add);
	printf("%d - %d =%d\n",a,b,sub);
	printf("%d * %d =%d\n",a,b,mul);
	printf("%d / %d =%0.2lf\n",a,b,div);
	return 0;
}