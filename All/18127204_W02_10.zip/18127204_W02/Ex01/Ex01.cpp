///ID: 18127204
///Name: Thai Nhat Tan
///Ex01: Hello, World!!!
#include<stdio.h>
int main()
{
	printf("Hello, World!!!");
	return 0;
}