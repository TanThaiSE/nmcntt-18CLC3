#include<stdio.h>
#include<iostream>
#include"BT6.2.h"
using namespace std;
void thuchienpheptinh()
{
	int tong, hieu, tich, thuong, a, b, c, d, e, t;
	char pt;
	printf("Phan so 1(a/b)=");	scanf_s("%d%d", &a, &b);
	printf("Phan so 2(c/d)=");	scanf_s("%d%d", &c, &d);
	tong = a * d + b * c;
	hieu = a * d - b * c;
	tich = a * c;
	thuong = a * d;
	t = b * d;
	e = b * c;
	cout << "Phep tinh(+,-,*,/)=";	cin >> pt;
	switch (pt)
	{
	case '+':

		if (t != 0)
			printf("Ket qua=%d / %d\n", tong, t);
		else
			printf("Phep tinh khong thuc hien duoc\n");
		break;

	case'-':
		if (t != 0)
			printf("Ket qua=%d / %d\n", hieu, t);
		else
			printf("Phep tinh khong thuc hien duoc\n");
		break;
	case'*':
		if (t != 0)
			printf("Ket qua=%d / %d\n", tich, t);
		else
			printf("Phep tinh khong thuc hien duoc\n");
		break;
	case'/':
		if (e != 0 && d != 0)
			printf("Ket qua=%d / %d\n", thuong, e);
		else
			printf("Phep tinh khong thuc hien duoc\n");
		break;

	}
}
void xuat2()
{
	system("cls");
	thuchienpheptinh();
	system("pause");
}