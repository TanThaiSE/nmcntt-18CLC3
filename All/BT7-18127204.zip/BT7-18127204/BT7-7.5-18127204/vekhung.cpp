#include<stdio.h>
#include"vekhung.h"
void vekhung()
{
	printf("*********************\n");
	printf("*                   *\n");
	printf("*  1.Bai tap 6.1.   *\n");
	printf("*  2.Bai tap 6.2.   *\n");
	printf("*  3.Bai tap 6.3.   *\n");
	printf("*  4.Bai tap 6.4.   *\n");
	printf("*  5.Thoat.         *\n");
	printf("*                   *\n");
	printf("*********************\n");
	printf("                     \n");
	printf("Lua chon cua ban (1-5):");
}