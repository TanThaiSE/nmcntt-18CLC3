#include<stdio.h>
#include<iostream>
#include"BT6.4.h"
int tinhtien(int &t)
{
	int s;
	if (t >= 401)
		s = b1 * 100 + b2 * 50 + b3 * 50 + b4 * 100 + b5 * 100 + b6 * (t - 400);
	if (t >= 301 && t < 401)
		s = b1 * 100 + b2 * 50 + b3 * 50 + b4 * 100 + b5 * (t - 300);
	if (t >= 201 && t < 301)
		s = b1 * 100 + b2 * 50 + b3 * 50 + b4 * (t - 200);
	if (t >= 151 && t < 201)
		s = b1 * 100 + b2 * 50 + b3 * (t - 150);
	if (t >= 101 && t < 151)
		s = b1 * 100 + b2 * (t - 100);
	if (t > 0 && t <= 101)
		s = b1 * t;
	return s;
}
int tinh(int &a, int &b)
{
	return b - a;
}
void chisodien(int &a, int &b)
{
	int d, e;
	printf("Nhap vao chi so dien cu:");	scanf_s("%d", &a);
	printf("Nhap vao chi so dien moi:"); scanf_s("%d", &b);
	d = tinh(a, b);
	e = tinhtien(d);
	printf("Tien dien phai tra:%d\n", e);
}

void xuat4()
{
	system("cls");
	int a, b;
	chisodien(a, b);
	system("pause");
}
