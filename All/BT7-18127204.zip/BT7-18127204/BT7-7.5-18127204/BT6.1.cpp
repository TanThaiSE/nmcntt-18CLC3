#include<stdio.h>
#include<iostream>
#include"BT6.1.h"
int kiemtraSNT(int a)
{
	int dem = 0;
	for (int i = 1; i <= a; i++)
	{
		if (a%i == 0)
		{
			dem++;
		}
	}
	if (dem == 2)
		return 1;
	else
		return 0;
}
void XuatSNT(int b)
{
	int k = 0;
	for (int j = 1; j <= b; j++)
	{
		if (kiemtraSNT(j) == 1)
		{
			k++;
			printf("#%d=%d\n", k, j);
		}
	}
	printf("Co tat ca %d so nguyen to\n", k);
}

void Nhapmotso(int &n)
{
	printf("Nhap N=");
	scanf_s("%d", &n);
	XuatSNT(n);
}
void xuat1()
{
	system("cls");
	int x;
	Nhapmotso(x);
	system("pause");
}

