#include<stdio.h>
#include<iostream>
#include<windows.h>
#include"BT6.1.h" 
#include"BT6.2.h"
#include"BT6.3.h"
#include"BT6.4.h"
#include"vekhung.h"
using namespace std;
int main()
{
	int chon;
	while (10)
	{
		system("cls");
		vekhung();
		scanf_s("%d", &chon);
		switch (chon)
		{
		case 1: xuat1();	break;
		case 2: xuat2();	break;
		case 3: xuat3();	break;
		case 4: xuat4();	break;
		default: exit(0);	break;
		}
	}
	system("pause");
	return 0;
}
