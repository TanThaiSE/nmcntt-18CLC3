#include<stdio.h>
#include<iostream>
int kiemtraSNT(int a);
void XuatSNT(int b);
void Nhapmotso(int &n);
void xuat1();

