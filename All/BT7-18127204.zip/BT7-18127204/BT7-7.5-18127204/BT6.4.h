int tinhtien(int &t);
int tinh(int &a, int &b);
void chisodien(int &a, int &b);
void xuat4();
#define b1 1549
#define b2 1600
#define b3 1858
#define b4 2340
#define b5 2615
#define b6 2701
