void xuat2();
void thuchienpheptinh();



