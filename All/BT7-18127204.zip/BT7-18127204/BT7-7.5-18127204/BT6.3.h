void kiemtra(float &a, float &b, float &c);
void nhapcanh(float &a, float &b, float &c);
void xuat3();
