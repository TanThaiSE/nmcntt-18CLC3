#include<stdio.h>
#include<math.h>
#include<iostream>
#include"BT6.3.h"
void kiemtra(float &a, float &b, float &c)
{
	if ((a + b) > c && (fabs(a - b)) < c && (b + c) > a && (fabs(b - c)) < a && (c + a) > b && (fabs(c - a)) < b)
	{
		printf("Lap thanh tam giac\n");
		{
			if ((a == b) && (b == c) && (c == a))
				printf("Loai tam giac la deu\n");
			else if ((a == b) || (a == c) || (b == c))
				printf("Loai tam giac la can\n");
			else if ((a*a == b * b + c * c) && (b == c) || (b*b == c * c + a * a) && (c == a) || (c*c == a * a + b * b) && (a == b))
				printf("Loai tam giac la vuong can\n");
			else if ((a*a == b * b + c * c) || (b*b == c * c + a * a) || (c*c == a * a + b * b))
				printf("Loai tam giac la vuong\n");
			else if ((a + b) > c && (fabs(a - b)) < c && (b + c) > a && (fabs(b - c)) < a && (c + a) > b && (fabs(c - a)) < b)
				printf("Loai tam giac la thuong\n");
		}
	}
	else
		printf("Khong lap thanh tam giac!\n");
}
void nhapcanh(float &a, float &b, float &c)
{
	printf("Nhap a,b,c=");	scanf_s("%f%f%f", &a, &b, &c);
	kiemtra(a, b, c);
}
void xuat3()
{
	system("cls");
	float a, b, c;
	nhapcanh(a, b, c);
	system("pause");
}