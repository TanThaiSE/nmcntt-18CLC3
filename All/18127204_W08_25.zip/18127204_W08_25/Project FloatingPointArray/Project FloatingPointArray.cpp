///ID: 18127204
///Name: Thai Nhat Tan
///Ex: Mang cac so thuc
#include<stdio.h>
#include"Ham.h"
#include<math.h>
#define MAX 1000
int main()
{
	int n;
	float a[MAX], b, c;
	nhapmang(a, n);
	b = lonnhat(a, n);
	printf("Gia tri lon nhat trong mang:%0.2f\n", b);
	c = duongnhonhat(a, n);
	printf("Gia tri duong nho nhat trong mang:%0.2f\n", c);
	tansuat(a, n);
	printf("Cac gia tri tang dan la:\n");
	sapxeptang(a, n);
	xuatmang(a, n);
	printf("\nCac gia tri am trong mang:\n");
	giatriam(a, n);
	return 0;
}