#ifndef _HAM_H_
#define _HAM_H_
void nhapmang(float a[], int &n);
void xuatmang(float a[], int &n);
float lonnhat(float a[], int n);
float duongnhonhat(float a[], int n);
void tansuat(float a[], int n);
void sapxeptang(float a[], int n);
void giatriam(float a[], int &n);
#endif 

