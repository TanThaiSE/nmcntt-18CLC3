#include<stdio.h>
#include"Ham.h"
#include<math.h>
void nhapmang(float a[], int &n)
///Intput: 3   ///Output: a[0]=6.1,a[1]=4.1,a[2]=3.1
///Intput: 4   ///Output: a[0]=12.2,a[1]=22.2,a[2]=23.2,a[3]=7.2
///Intput: 5   ///Output: a[0]=1.6,a[1]=3.6,a[2]=5.6,a[3]=20.6,a[4]=30.6
{
	printf("Nhap n=");	scanf_s("%d", &n);
	for (int i = 0; i < n; i++)
	{
		printf("Nhap a[%d]=", i);
		scanf_s("%f", &a[i]);
	}
}
void xuatmang(float a[], int &n)
///Output: 6.1       4.1  ,  3.1
///Output: 12.2   22.2    23.2   7.2
///Output: 1.6   3.6   5.6   20.6   30.6
{
	for (int i = 0; i < n; i++)
	{
		printf("%f   ", a[i]);
	}
}
float lonnhat(float a[], int n)
///Output: 6.1  
///Output: 23.2
///Output: 30.6
{
	float max = a[0];
	for (int i = 0; i < n; i++)
	{
		if (a[i] > max)
		{
			max = a[i];
		}
	}
	return max;
}
float duongnhonhat(float a[], int n)
///Output:3.1
///Output:7.2
///Output:1.6
{
	float min = -1;
	for (int i = 0; i < n; i++)
	{
		if (a[i] > 0)
		{
			if (a[i] < min || min == -1)
			{
				min = a[i];
			}
		}
	}
	return min;
}
void tansuat(float a[], int n)
///Output: 6.1 xuat hien 1 lan  4.1 xuat hien 1 lan   3.1 xuat hien 1 lan
///Output: 12.2 xuat hien 1 lan  22.2 xuat hien 1 lan   23.2 xuat hien 1 lan   7.2 xuat hien 1 lan
///Output: 1.6 xuat hien 1 lan  3.6 xuat hien 1 lan   5.6 xuat hien 1 lan   30.6 xuat hien 1 lan  30 xuat hien 1 lan
{
	int b[1000]; int dem;
	for (int i = 0; i < n; i++)
	{
		b[i] = 1;
	}
	for (int i = 0; i < n; i++)
	{
		if (b[i] == 1)
		{			
			b[i] = 0;
			dem = 1;
			for (int j = i + 1; j < n; j++)
			{
				if(a[i]==a[j])
				{
					dem++;
					b[j] = 0;
				}
			}
			printf("Gia tri %f xuat hien %d lan\n", a[i], dem);
		}
		
	}
	
}
void sapxeptang(float a[], int n)
///Output: 3.1       4.1  ,  6.1
///Output: 7.2   12.2    22.2   23.2
///Output: 1.6   3.6   5.6   20.6   30.6
{
	float temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (a[i] > a[j])
			{
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}
void giatriam(float a[], int &n)
///Output: Mang khong co gia tri am
///Output: Mang khong co gia tri am
///Output: Mang khong co gia tri am
{
	float b[1000], dem = 0;
	int k = 0;
	for (int i = 0; i < n; i++)
	{
		if (a[i] < 0)
		{
			b[k] = a[i];
			k++;
			dem = 1;
		}
	}
	if (dem == 0)
	{
		printf("Mang khong co gia tri am");
	}
	else
	{
		xuatmang(b, k);
	}
}