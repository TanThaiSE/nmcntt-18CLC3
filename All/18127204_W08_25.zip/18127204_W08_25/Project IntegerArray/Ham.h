#ifndef _HAM_H_
#define _HAM_H_
void nhapmang(int a[], int &n);
void xuatmang(int a[], int n);
int kiemtrasonguyento(int n);
int nguyentocuoicung(int a[], int &n);
void xanhat(int a[], int &n);
void dautientrongdoan(int a[], int &n);
int uocchunglonnhat(int a,int b);
int timuocchunglonnhat(int a[], int n);
void trituyetdoi(int a[], int &n);
int kiemtrasodautien(int n);
void lietkedaule(int a[], int &n);
int kiemtrahangchuc(int n);
int tongchuc(int a[], int n);
float tbnguyento(int a[], int n);
void lietke(int a[], int n);
int kttang(int a[], int n);
void sapxepgiam(int a[], int n);
void nguyentotang(int a[], int n);
void themvitri(int a[], int &n);
void sapxeptang(int a[], int n);
void thembaotoan(int a[], int n, int x);
void xoavitri(int a[], int &n);
void xoa(int a[], int &n, int vitrixoa);
void xoanguyento(int a[], int &n);
void giatrile(int a[], int &n);

#endif 

