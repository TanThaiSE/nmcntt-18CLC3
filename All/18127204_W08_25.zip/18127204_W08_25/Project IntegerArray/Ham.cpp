#include<stdio.h>
#include"Ham.h"
#include<math.h>
void nhapmang(int a[], int &n)
///Intput: 3   ///Output: a[0]=5,a[1]=3,a[2]=2
///Intput: 4   ///Output: a[0]=10,a[1]=20,a[2]=11,a[3]=5
///Intput: 5   ///Output: a[0]=1,a[1]=3,a[2]=5,a[3]=20,a[4]=30
{
	printf("Nhap n:");	scanf_s("%d", &n);
	for (int i = 0; i < n; i++)
	{
		printf("a[%d]=", i);	scanf_s("%d", &a[i]);
	}
}
void xuatmang(int a[], int n)
///Output: 5   3    2
///Output: 10  20    11   5
///Output: 1   3   5  20  30
{
	for (int i = 0; i < n; i++)
	{
		printf("%d ", a[i]);
	}
}
int kiemtrasonguyento(int n)
{
	int dem = 0;
	for (int i = 2; i <= n; i++)
	{
		if (n%i == 0)
		{
			dem++;
		}
	}
	if (dem == 1)
	{
		return 1;
	}
	else
		return 0;
}
int nguyentocuoicung(int a[], int &n)
///Output: 2
///Output: 5
///Output: 5
{
	int s = -1;
	for (int i = n - 1; i > 0; i--)
	{
		if (kiemtrasonguyento(a[i]) == 1)
		{
			s = a[i];
			break;
		}
	}
	return s;
}
void xanhat(int a[], int &n)
///Intput: x=15	///Output:2 
///Intput: x=5  ///Output: 20
///Intput: x=7  ///Output: 30
{
	float x, e, d = 0, f;
	printf("\nNhap x:");	scanf_s("%f", &x);
	for (int i = 0; i < n; i++)
	{
		e = fabs(a[i] - x);
		if (e > d)
		{
			d = e;
			f = a[i];
		}
	}
	printf("gia tri trong mang xa gia tri x nhat la:%f\n", f);
}
void dautientrongdoan(int a[], int &n)
///Intput: x=15,y=30  ///Output:15
///Intput: x=5,y=20   ///Output:10
///Intput: x=10,y=70  ///Output:20
{
	float x, y, e = 0;
	do
	{
		printf("Nhap x,y:");	scanf_s("%f%f", &x, &y);
	} while (x > y);
	for (int i = 0; i < n; i++)
	{
		if (a[i] > x&&a[i] < y)
		{
			e = a[i];
			break;
		}
		else
			e = x;
	}	
	printf("\nGia tri dau tien trong mang nam trong khoang:%f", e);
}
int uocchunglonnhat(int a, int b)
{
	a = fabs(a);
	b = fabs(b);
	while(a!=b)
	{
		if (a > b)
		{
			a = a - b;
		}
		else
		{
			b = b - a;
		}
	}
	return a;
}
int timuocchunglonnhat(int a[], int n)
///Output: 1
///Output: 1
///Output: 1
{
	int m;
			m = uocchunglonnhat(a[0], a[1]);
			for (int i = 0; i < n - 2; i++)
			{
				m = uocchunglonnhat(m, a[i + 2]);
			}
	return m;
}
void trituyetdoi(int a[], int &n)
///Output: 5   3    
///Output: 20  11
///Output: Mang khong co gia tri nao
{
	int dem = 0;
	for (int i = 0; i < n; i++)
	{
		if ((a[i] - fabs(a[i + 1])) > 0)
		{
			dem = 1;
			printf("%d   ", a[i]);
		}
	}
	if (dem == 0)
	{
		printf("Mang khong co gia tri nao\n");
	}
}
int kiemtrasodautien(int n)
{
	int m;
	while (n != 0)
	{
		m = n % 10;
		n = n / 10;
	}
	return m;
}
void lietkedaule(int a[], int &n)
///Output: 5   3    
///Output: 10  11   5
///Output: 1   3   5    30
{
	int dem = 0;
	for (int i = 0; i < n; i++)
	{
		if (kiemtrasodautien(a[i]) == 1 || kiemtrasodautien(a[i]) == 3 || kiemtrasodautien(a[i]) == 5 || kiemtrasodautien(a[i]) == 7 || kiemtrasodautien(a[i]) == 9)
		{
			dem = 1;
			printf("%d  ", a[i]);
		}
	}
	if (dem == 0)
	{
		printf("\nKhong co so nao bat dau bang chu so le");
	}
}
int kiemtrahangchuc(int n)
{
	int m;
	n = n / 10;
	m = n % 10;
	return m;
}
int tongchuc(int a[], int n)
///Output: 0
///Output: 0
///Output: 0
{
	int s = 0, dem = 0;
	for (int i = 0; i < n; i++)
	{
		if (kiemtrahangchuc(a[i]) == 5)
		{
			dem = 1;
			s = s + a[i];
		}
	}
	if (dem == 0)
	{
		return 0;
	}
	else
	{
		return s;
	}
}
float tbnguyento(int a[], int n)
///Output: 3.333333
///Output: 8
///Output: 4
{
	float d;
	int dem = 0, s = 0, b = 0;
	for (int i = 0; i < n; i++)
	{
		if (kiemtrasonguyento(a[i]) == 1)
		{
			s = s + a[i];
			dem++;
			b = 1;
		}
	}
	if (b == 0)
	{
		d = -1;
	}
	else
	{
		d = s * 1.0 / dem;
	}
	return d;
}
void lietke(int a[], int n)
///Output: 5 xuat hien 1 lan  3 xuat hien 1 lan   2 xuat hien 1 lan
///Output: 10 xuat hien 1 lan  20 xuat hien 1 lan   11 xuat hien 1 lan   5 xuat hien 1 lan
///Output: 1 xuat hien 1 lan  3 xuat hien 1 lan   5 xuat hien 1 lan   20 xuat hien 1 lan  30 xuat hien 1 lan
{
	int b[1000], dem;
	for (int i = 0; i < n; i++)
	{
		b[i] = 1;
	}
	for (int i = 0; i < n; i++)
	{
		if (b[i] == 1)
		{
			b[i] = 0;
			dem = 1;
			for (int j = i + 1; j < n; j++)	
			{
				if (a[i] == a[j])
				{
					dem++;
					b[j] = 0;
				}
			}
			printf("\nGia tri %d xuat hien %d lan\n", a[i], dem);
		}
		
	}
}
int kttang(int a[], int n)
///Output: Mang khong tang dan
///Output: Mang khong tang dan
///Output: Mang  tang dan
{
	int dem = 0;
	for (int i = 0; i < n; i++)
	{
		if (a[i] < a[i + 1])
		{
			dem++;
		}
	}
	if (dem == n - 1)
	{
		return 1;
	}
}
void sapxepgiam(int a[], int n)
///Output: 5   3    2
///Output: 20  11    10   5
///Output: 30   20   5  3  1
{
	int temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (a[i] < a[j])
			{

				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}
void nguyentotang(int a[], int n)
///Output: 2   3    5
///Output: 20 5 10 11       
///Output: 30 20 3 5 1
{
	int temp;
	for (int i = 0; i < n; i++)
	{
		if (kiemtrasonguyento(a[i]) == 1)
		{
			for (int j = i + 1; j < n; j++)
			{
				if (kiemtrasonguyento(a[j]) == 1)
				{
					if (a[i] > a[j])
					{
						temp = a[j];
						a[j] = a[i];
						a[i] = temp;
					}
				}			
			}
		}
	}
}
void themvitri(int a[], int &n)
///Intput:x=1,k=2   ///Output: 2  3  1  5
///Intput:x=2,k=3     ///Output: 20 5 10 2 11
///Intput:x=12,k=4      ///Output: 30 20 3 5 12 1
{
	int x,k;
	printf("\nNhap x=");					scanf_s("%d", &x);
	printf("\nNhap vi tri them:");		scanf_s("%d", &k);
	if (k >= 0 && k < n)
	{
		for (int i = n - 1; i >= k; i--)
		{
			a[i+1] = a[i];
		}
		a[k] = x;
		n++;
	}
}
void sapxeptang(int a[], int n)
{
	int temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (a[i] > a[j])
			{

				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}
void thembaotoan(int a[], int n, int x)
///Input: x=10    ///Output:1  2   3 5 10
///Input: x=21    ///Output:2 5 10  11 20 21
///Input: x=13    ///Output:1 3  5 12 13 20 30
{
if (x > a[n - 1])
	{
		a[n] = x;
	}
	else
	{
		int i = n;
		while (a[i - 1] > x&i > 0)
		{
			a[i] = a[i - 1];
			i--;	
		}
		a[i] = x;
	}
	xuatmang(a, n + 1);
}
void xoavitri(int a[], int &n)
///Input: 2    ///Output: 1 2 3 5
///Input: 3    ///Output: 2 5 10 11 20
///Input: 4    ///Output: 1 3 13 5 20 30
{
	int k;
	do
	{
		printf("\nNhap vi tri xoa:");		scanf_s("%d", &k);
	} while (k<0 || k>n - 1);
	for (int i = k; i < n - 1; i++)
	{
		a[i] = a[i+1];
	}
	n = n - 1;
}
void xoa(int a[], int &n, int vitrixoa)
{
	for (int i = vitrixoa; i < n; i++)
	{
		a[i] = a[i + 1];
	}
	n--;
}
void xoanguyento(int a[], int &n)
{
	///Output: 1	
	///Output: 10 20	
	///Output: 1 20 30
	for (int i = 0; i < n; i++)
	{
		if (kiemtrasonguyento(a[i]) == 1)
		{
			xoa(a, n,i);
			i--;
		}	
	}
}
void giatrile(int a[], int &n)
///Output: 1
/// Output: Khong co gia tri thoa man
///Output: 1
{
	int b[1000], k = 0, dem = 0;
		for (int i = 0; i < n; i++)
		{
			if (a[i] % 2 != 0)
			{
				b[k] = a[i];
				k++;
				dem = 1;
			}
		}
		if (dem == 0)
		{
			printf("Khong co gia tri thoa man");
		}
		else
		{
			xuatmang(b, k);
		}
}