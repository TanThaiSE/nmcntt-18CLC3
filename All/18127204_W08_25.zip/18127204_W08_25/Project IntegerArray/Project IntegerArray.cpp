///ID: 18127204
///Name: Thai Nhat Tan
///Ex: Mang cac so nguyen
#include<stdio.h>
#include"Ham.h"
#include<math.h>
#define MAX 1000
int main()
{
	int a[MAX], n, m, b, d, x;
	float c;
	nhapmang(a, n);
	xuatmang(a, n);
	m = nguyentocuoicung(a, n);
	printf("\nSo nguyen to cuoi cung la:%d", m);
	xanhat(a, n);
	dautientrongdoan(a, n);
	b = timuocchunglonnhat(a, n);
	printf("\nUoc chung lon nhat cua cac phan tu trong mang:%d\n", b);
	printf("Cac gia tri co tri tuyet doi lon hon sau no la:\n");
	trituyetdoi(a, n);
	printf("\nCac gia tri co chu so dau tien la so le la:\n");
	lietkedaule(a, n);
	d = tongchuc(a, n);
	printf("\nTong cac gia tri co chu so hang chuc la chu so 5 la:%d", d);
	c = tbnguyento(a, n);
	printf("\nTrung binh cong cac so nguyen to trong mang:%f", c);
	lietke(a, n);
	if (kttang(a, n) == 1)
		printf("Mang tang dan\n");		
	else
		printf("Mang khong tang dan\n");
	printf("Mang cac so nguyen giam dan\n");
	sapxepgiam(a, n);
	xuatmang(a, n);
	printf("\nMang cac so nguyen to tang dan\n");
	nguyentotang(a, n);
	xuatmang(a, n);
	themvitri(a, n);
	xuatmang(a, n);
	sapxeptang(a, n);
	printf("\nNhap gia tri x=");	scanf_s("%d", &x);
	thembaotoan(a, n, x);	
	xoavitri(a, n);
	xuatmang(a, n);
	printf("\nMang da xoa so nguyen to:");
	xoanguyento(a, n);
	xuatmang(a, n);
	printf("\nMang chi chua cac gia tri le:");
	giatrile(a, n);

	return 0;
}