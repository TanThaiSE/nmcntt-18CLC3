#include<stdio.h>
#include<math.h>
int main()
{
	float x, p, q;
	printf("Nhap p,q=");
	scanf_s("%f%f", &p, &q);
	x = pow(sqrt((pow(p, 6) / 27) + (q*q / 4)) - q / 2, 1.0 / 3) - pow(sqrt((pow(p, 6) / 27) + (q*q / 4)) + q / 2, 1.0 / 3);
	printf("nghiem cua phuong trinh x^3+p^2*x+q=0 la: %f", x);
	return 0;
}