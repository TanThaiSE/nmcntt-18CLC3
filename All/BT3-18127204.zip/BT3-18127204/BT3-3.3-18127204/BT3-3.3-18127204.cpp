#include<stdio.h>
int main()
{
	float a, b, c;
	printf("Do C=");
	scanf_s("%f", &a);
	b = a * 1.8 + 32;
	c = a + 273;
	printf("Do F = %0.1f\n", b);
	printf("Do C = %0.1f", c);
	return 0;
}