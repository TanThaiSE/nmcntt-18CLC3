#include<stdio.h>
int main()
{
	int a, b, c, d, e, h, t;
	printf("Thoi diem T1 (h m s) =");
	scanf_s("%d%d%d", &a, &b, &c);
	printf("Thoi diem T2 (h m s) =");
	scanf_s("%d%d%d", &d, &e, &h);
	t = (d * 3600 + e * 60 + h) - (a * 3600 + b * 60 + c);
	printf("Khoang cach=%d", t);
	return 0;
}
