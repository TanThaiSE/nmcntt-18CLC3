#include<stdio.h>
#include<math.h>
int main()
{
	int a, s, i;
	do
	{
		printf("Nhap vao so nguyen duong N:");
		scanf_s("%d", &a);
	} while (a <= 0);
	s = 0;
	for (i = 1; i*i <= a; i += 1)
	{
		s = s + i * i;
	}
	printf("S=%d", s);
	return 0;
}
