#include<stdio.h>
int main()
{
	int a, b, c, d, e, f;
	printf("nhap vao thang va nam");
	scanf_s("%d%d", &a, &b);
	c = 31, d = 30, e = 29, f = 28;
	switch (a)
	{
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		printf("Thang %d nam %d co %d ngay", a, b, c);
		break;
	case 4:
	case 6:
	case 9:
	case 11:
		printf("Thang %d nam %d co %d ngay", a, b, d);
		break;
	case 2:
		if (b % 4 == 0 && b % 100 != 0)
			printf("Thang %d nam %d co %d ngay", a, b, e);
		else if (b % 400 == 0)
			printf("Thang %d nam %d co %d ngay", a, b, e);
		else
			printf("Thang %d nam %d co %d ngay", a, b, f);
		break;
	defaul: printf("Khong ton tai");
		break;
	}
	return 0;
}