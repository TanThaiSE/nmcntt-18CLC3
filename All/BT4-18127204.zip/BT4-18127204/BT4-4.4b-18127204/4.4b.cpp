#include<stdio.h>
#include<math.h>
int main()
{
	int a, i;
	float s;
	do
	{
		printf("Nhap vao so nguyen duong N:");
		scanf_s("%d", &a);
	} while (a <= 0);
	s = 0;
	for (i = 1; i <= a; i += 1)
	{
		s = s + -(1.0 * 1 / i)*(pow(-1, i));
	}
	printf("ln(2)=%f", s);
	return 0;
}