#include<stdio.h>
#include<math.h>

int main()
{
	float a, b, c, d, x1, x2, x3;
	printf("Nhap he so a,b,c=");
	scanf_s("%f%f%f", &a, &b, &c);
	if (a == 0)
	{
		if (b == 0)
		{
			if (c == 0)
				printf("Phuong trinh vo so nghiem!");
			else if (c != 0)
				printf("Phuong trinh vo nghiem!");
		}
		else
		{
			if (c != 0)
				x3 = -c * 1.0 / b;
			printf("Phuong trinh co mot nghiem la:%0.1f", x3);
		}
	}
	else if (a != 0)
	{
		d = b * b - 4 * a*c;
		if (d < 0)
			printf("Phuong trinh vo nghiem!");
		else if (d > 0)
		{
			x1 = (-b - sqrt(d)) / (2 * a);
			x2 = (-b + sqrt(d)) / (2 * a);
			printf("Nghiem 1 =%0.1f\nNgiem 2 =%0.1f\n", x1, x2);
		}
		else if (d = 0)
			printf("Nghiem kep=%0.1f", -b * 1.0 / (2 * a));
	}
	return 0;
}
