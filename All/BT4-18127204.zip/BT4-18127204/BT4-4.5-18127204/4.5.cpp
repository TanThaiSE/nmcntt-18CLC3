#include<stdio.h>
int main()
{
	int a, b;
	b = 0;
	for (a = 100; a < 1000; a += 1)
	{
		if ((a / 10) % 10 == a / 100 + a % 10)
		{
			b = b + 1;
			printf("%d:%d thoa tinh chat\n", b, a);
		}continue;
	}
	printf("co tat ca %d thoa tinh chat\n", b);
	return 0;
}