#include<stdio.h>
#include<math.h>
int main()
{
	int a, i;
	float s;
	do
	{
		printf("Nhap vao so nguyen duong N:");
		scanf_s("%d", &a);
	} while (a <= 0);
	s = 4;
	for (i = 1; i <= a; i = i + 1)
	{
		s = s + 4 * ((pow(-1, i))*1.0 / (2 * i + 1));
	}
	printf("PI=%f", s);
	return 0;
}