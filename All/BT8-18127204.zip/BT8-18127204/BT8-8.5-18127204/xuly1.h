#pragma once
void dem(char s[]);
void xoakitu(char s[], int vitrixoa);
void bokhoangtrangdau(char s[]);
void bokhoangtrangcuoi(char s[]);
void bokhoangtrangduthua(char s[]);
void viethoa(char s[]);