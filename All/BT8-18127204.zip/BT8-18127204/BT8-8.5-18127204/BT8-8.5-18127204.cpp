#include<stdio.h>
#include<string.h>
#include"xuly1.h"
int main()
{
	char s[100];
	printf("Nhap chuoi:");	gets_s(s);
	dem(s);
	bokhoangtrangdau(s);
	bokhoangtrangcuoi(s);
	bokhoangtrangduthua(s);
	viethoa(s);
	printf("Chuoi moi la:\n%s", s);
	return 0;
}