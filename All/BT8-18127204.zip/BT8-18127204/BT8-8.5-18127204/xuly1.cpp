#include<stdio.h>
#include<string.h>
void dem(char s[])
{
	int n = strlen(s);
	int dem = strlen(s);
	for (int i = 0; i < n-1; i++)
	{
		if (s[i] == 32 || s[i] == ',' || s[i] == '.' || s[i] == '?' || s[i] == '!')
		{
			dem--;
		}
	}
	printf("Chuoi co %d tu\n", dem);
}
void xoakitu(char s[], int vitrixoa)
{
	for (int i = vitrixoa + 1; i < strlen(s); i++)
	{
		s[i - 1] = s[i];
	}
	s[strlen(s) - 1] = '\0';
}
void bokhoangtrangdau(char s[])
{
	while (1)
	{
		if (s[0] == 32)
		{
			xoakitu(s, 0);
		}
		else
		{
			break;
		}
	}

}
void bokhoangtrangcuoi(char s[])
{
	while (1)
	{
		if (s[strlen(s) - 1] == 32)
		{
			xoakitu(s, strlen(s) - 1);
		}
		else
		{
			break;
		}
	}
}
void bokhoangtrangduthua(char s[])
{
	int n = strlen(s);
	for (int i = 0; i < strlen(s); i++)
	{
		if (s[i] == 32 && s[i + 1] == 32)
		{
			for (int j = i; j < strlen(s); j++)
			{
				s[j] = s[j + 1];
			}
			n--;
			i--;
		}
	}
}
void viethoa(char s[])
{
	for (int i = 0; i < strlen(s); i++)
	{
		if (s[i] >= 'a'&&s[i] <= 'z'&&(i==0||s[i - 1] == 32))
		{
		s[i] = s[i] - 32;
		}
	}
}