#include<stdio.h>
#include"Ham.h"
#include<string.h>
#define MAX 1000
int main()
{
	int d = 0;
	char s[MAX];
	int a[MAX];
	printf("Nhap chuoi=");
	for (int i = 0; i < 1000; i++)
		a[i] = 1;
	gets_s(s);
	for (int i = 0; i < strlen(s) - 1; i++)
	{
		for (int j = i + 1; j < strlen(s); j++)
		{
			if (s[i] == s[j])
			{
				a[i]++;
			}
		}
		if (a[i] > d)	d = a[i];
	}
	for (int i = 0; i < strlen(s); i++)
	{
		if (a[i] == d)
			printf("%c : %d\n", s[i], a[i]);
	}
	return 0;
}