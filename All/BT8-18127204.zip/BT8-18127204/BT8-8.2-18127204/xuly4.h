#pragma once
void kiemtracsc(int a[], int n);