#include<stdio.h>
#include"xuly3.h"
#include"xuly1.h"
int kiemtradoixung(int a[], int &n)
{
	int dem = 1;
	for (int i = 0; i < (n/2); i++)
	{
		if (a[i] == a[n - 1 - i]) 
		{
			dem = 0;
		}
	}
	return dem;
}