#include<stdio.h>
#include"xuly2.h"
#include"xuly1.h"
void kiemtratangdan(int a[], int &n)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
	{
		if (a[i] < a[i + 1])
		{
			dem++;
		}
	}
	if (dem == n-1)
	{
		printf("Mang tang dan\n");
	}
	else
		printf("Mang khong tang dan\n");
}