#pragma once
int kiemtradoixung(int a[], int &n);
