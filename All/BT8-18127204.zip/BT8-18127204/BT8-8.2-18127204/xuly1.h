#pragma once
void nhapmang(int a[], int &n);
void xuatmang(int a[], int &n);