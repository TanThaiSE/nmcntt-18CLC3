#include<stdio.h>
#include"xuly4.h"
#include"xuly1.h"
void kiemtracsc(int a[], int n)
{
	int dem = 0, d;
	d = a[1] - a[0];
	for (int i = 2; i < n; i++)
	{
		if (a[i] - a[i - 1] == d)
		{
			dem++;
		}
	}
	if (dem == (n - 2))
	{
		printf("Mang lap thanh cap so cong");
	}
	else
	{
		printf("Mang khong lap thanh cap so cong");
	}
}