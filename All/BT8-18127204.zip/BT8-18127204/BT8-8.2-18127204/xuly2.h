#pragma once
void kiemtratangdan(int a[], int &n);