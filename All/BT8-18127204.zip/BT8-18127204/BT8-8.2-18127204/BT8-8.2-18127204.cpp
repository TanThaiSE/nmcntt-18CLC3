#include<stdio.h>
#include"xuly2.h"
#include"xuly4.h"
#include"xuly3.h"
#include"xuly1.h"
#define MAX 100
int main()
{
	int a[MAX], n;
	
	nhapmang(a, n);
	xuatmang(a, n);
	kiemtratangdan(a, n);
	if (kiemtradoixung(a, n) == 0)
	{
		printf("Mang doi xung\n");
	}
	else
		printf("Mang khong doi xung.\n");
	kiemtracsc(a, n);
	return 0;
}