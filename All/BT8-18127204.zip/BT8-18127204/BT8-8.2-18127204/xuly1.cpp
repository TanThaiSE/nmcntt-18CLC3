#include<stdio.h>
#include"xuly1.h"
void nhapmang(int a[], int &n)
{
	printf("Nhap kich thuoc:");	scanf_s("%d", &n);
	for (int i = 0; i < n; i++)
	{
		printf("Nhap a[%d]:", i);	scanf_s("%d", &a[i]);
	}
}
void xuatmang(int a[], int &n)
{
	for (int i = 0; i < n; i++)
	{
		printf("a[%d]=%d\n", i, a[i]);
	}
}