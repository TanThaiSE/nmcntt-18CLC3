#include<stdio.h>
#include<string.h>
#define MAX 1000
int main()
{
	char s1[MAX], s2[MAX], s3[MAX];
	printf("Chuoi 1:");		gets_s(s1);
	printf("Chuoi 2:");		gets_s(s2);
	strncpy_s(s3, s2, strlen(s2) / 2);
	strcat_s(s3, s1);
	int n = strlen(s1) + strlen(s2) / 2;
	for (int i = strlen(s2) / 2; i < strlen(s2); i++)
	{
		s3[n] = s2[i];
		n++;
	}
	s3[strlen(s1) + strlen(s2)] = '\0';
	printf("\n%s", s3);
	return 0;
}