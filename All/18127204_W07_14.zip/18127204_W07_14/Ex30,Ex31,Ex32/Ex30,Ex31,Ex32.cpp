///ID: 18127204
///Name: Thai Nhat Tan
///Ex30,31,32: kiem tra so
#include<stdio.h>
#include"Ham.h"
int main()
{
	int n;
	printf("Nhap n:");	scanf_s("%d", &n);
	if (kiemtrasohoanthien(n) == 1)
		printf("%d la so hoan thien\n", n);
	else
		printf("%d khong la so hoan thien\n", n);
	if (kiemtrasonguyento(n)==1)
		printf("%d la so nguyen to\n", n);
	else 
		printf("%d khong la so nguyen to\n", n);
	if (kiemtrasochinhphuong(n) == 1)
		printf("%d la so chinh phuong\n", n);
	else
		printf("%d khong la so chinh phuong\n", n);
}