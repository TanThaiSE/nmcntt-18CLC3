#ifndef _HAM_H_
#define _HAM_H_
int kiemtrasonguyento(int n);
int kiemtrasohoanthien(int n);
int kiemtrasochinhphuong(int n);
#endif
