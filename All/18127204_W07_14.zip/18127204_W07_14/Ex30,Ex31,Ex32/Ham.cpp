#include<stdio.h>
#include"Ham.h"
int kiemtrasohoanthien(int n)
{
	int dem = 0;
	for (int i = 1; i < n; i++)
	{
		if (n%i == 0)
			dem += i;
	}
	if (n - dem == 0)
		return 1;
	else
		return 0;
}
int kiemtrasonguyento(int n)
{
	int dem = 0;
	for (int i = 2; i <= n; i++)
	{
		if (n%i == 0)
			dem++;
	}
	if (dem == 1)
		return 1;
	else
		return 0;
}
int kiemtrasochinhphuong(int n)
{
	int dem = 0;
	for (int i = 1; i <= n; i++)
	{
		if (i*i == n)
			dem++;
	}
	if (dem == 1)
		return 1;
	else
		return 0;
}