///ID: 18127204
///Name: Thai Nhat Tan
///Ex62,63: Tim UCLN va BCNN
#include<stdio.h>
#include"Ham.h"
int main()
{
	int n, m, y, z;
	printf("Nhap n,m:");	scanf_s("%d%d", &n, &m);
	y = tinhucln(n,m);
	printf("UCLN cua 2 so la:%d\n", y);
	z = tinhbcnn(n, m);
	printf("BCNN cua 2 so la:%d", z);
	return 0;
}