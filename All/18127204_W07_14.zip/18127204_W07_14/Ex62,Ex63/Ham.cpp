#include<stdio.h>
#include"Ham.h"
int tinhucln(int n, int m)
{
	while (n!=m)
	{
		if (n > m)
		{
			n = n - m;
		}
		else
		{
			m = m - n;
		}
	}
	return m;
}
int tinhbcnn(int n, int m)
{
	int y;
	y = tinhucln(n, m);
	return 1.0*n * m / y;
}