#ifndef _HAM_H
#define _HAM_H_
int tinhucln(int n, int m);
int tinhbcnn(int n, int m);
#endif
