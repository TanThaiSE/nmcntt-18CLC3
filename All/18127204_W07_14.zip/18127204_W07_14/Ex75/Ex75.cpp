///ID: 18127204
///Name: Thai Nhat Tan
///Ex75: Kiem tra so
#include<stdio.h>
#include"Ham.h"
int main()
{
	int n;
	printf("Nhap so:");	scanf_s("%d", &n);
	kiemtra(n);
}
