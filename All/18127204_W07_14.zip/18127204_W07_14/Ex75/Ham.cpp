#include<stdio.h>
#include"Ham.h"
void kiemtra(int n)
{
	int p = 1;
	int i = 0;
	for (i = 0; p < n; i++)
	{
		p = p * 2;
	}
	if (p == n)
	{
		printf("%d co dang 2^%d", n, i);
	}
	else
		printf("%d khong co dang 2^k", n);
}