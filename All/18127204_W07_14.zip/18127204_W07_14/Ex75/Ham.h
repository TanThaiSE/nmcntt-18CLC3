#ifndef _HAM_H_
#define _HAM_H_
void kiemtra(int n);
#endif