///ID: 18127204
///Name: Thai Nhat Tan
///Ex52,58: kiem tra so
#include<stdio.h>
#include"Ham.h"
int main()
{
	int n, y;
	printf("Nhap n:");	scanf_s("%d", &n);
	y = chusonhonhat(n);
	printf("Chu so nho nhat la:%d\n", y);
	if (kiemtrasotoanchan(n) == 1)
		printf("%d la so toan chan\n", n);
	else
		printf("%d khong la so toan chan\n", n);
	return 0;
}