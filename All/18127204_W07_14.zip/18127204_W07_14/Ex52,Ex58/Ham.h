#ifndef _HAM_H_
#define _HAM_H_
int chusonhonhat(int n);
int kiemtrasotoanchan(int n);
#endif

