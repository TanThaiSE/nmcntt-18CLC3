#include<stdio.h>
#include"Ham.h"
int chusonhonhat(int n)
{
	int a, b;
	b = 9;
	while (n > 0)
	{
		a = n % 10;
		if (b > a)
		{
			b = a;
		}
		n = n / 10;
	}
	return b;
}
int kiemtrasotoanchan(int n)
{
	int dem = 0, s = 0, a;
	while (n > 0)
	{
		a = n % 10;
		if (a % 2 == 0)
		{
			dem++;
		}
		s++;
		n = n / 10;
	}
	if (dem - s == 0)
		return 1;
	else
		return 0;
}