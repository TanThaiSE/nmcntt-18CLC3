#include<stdio.h>
#include"Ham.h"
int solveLinear(double a, double b, double &x)
{	
	if (a != 0)
	{
		x = -b / a;
		return 1;
	}
	else
	{
		if (b == 0)
			return -1;
		else
			return 0;
	}
}