#ifndef _HAM_H_
#define _HAM_H_
int solveLinear(double a, double b, double &x);
#endif