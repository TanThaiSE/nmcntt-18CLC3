///ID: 18127204
///Name: Thai Nhat Tan
///Ex80: Solve linear equation ax + b = 0
#include<stdio.h>
#include"Ham.h"
#include<iostream>
using namespace std;
int main()
{
	double a, b, x;
	cout << "Nhap a,b:";	cin >> a >> b;
	if (solveLinear(a, b, x) == 1)
	{
		cout << x;
	}
	else if (solveLinear(a, b, x) == -1)
	{
		printf("Phuong trinh vo so nghiem");
	}
	else if (solveLinear(a, b, x) == 0)
	{
		printf("Phuong trinh vo nghiem\n");
	}
	
	return 0;
}