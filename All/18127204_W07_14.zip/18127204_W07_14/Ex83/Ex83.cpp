///ID: 18127204
///Name: Thai Nhat Tan
///Ex83: rock, scissors, paper
//#include"Ham.h"
#include<iostream>
#include <conio.h>
#include <time.h>
#include <stdlib.h>
#include <windows.h>
#include"Ham.h"
using namespace std;
int main()
{
	game();
	return 0;
}