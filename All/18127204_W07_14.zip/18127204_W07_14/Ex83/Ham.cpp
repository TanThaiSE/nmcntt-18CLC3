#include<stdio.h>
#include<iostream>
#include"Ham.h"
#include <time.h>
#include <windows.h>
using namespace std;
void game()
{
	srand(time(0));
	char s1, s2;
	int d1 = 0, d2 = 0, d3 = 0, d = 0;
X:
	while (1)
	{
		cout << "Player 1 chooses:";
		cin >> s1;

		if (s1 == 82)
		{
			cout << "Player 2 chooses:";
			cin >> s2;

			if (s2 == 83)
			{
				cout << "Player 1 win";
				d1++;
				d++;
				Sleep(2000);
				system("cls");

			}
			else if (s2 == 80)
			{
				d2++;
				d++;
				cout << "Player 2 win";
				Sleep(2000);
				system("cls");
			}
			else if (s2 == 82)
			{
				d3++;
				d++;
				system("cls");
			}

		}
		else if (s1 == 83)
		{
			cout << "Player 2 chooses:";
			cin >> s2;
			if (s2 == 82)
			{
				d2++;
				d++;
				cout << "Player 2 win";
				Sleep(2000);
				system("cls");

			}
			else if (s2 == 80)
			{
				d1++;
				d++;
				cout << "Player 1 win";
				Sleep(2000);
				system("cls");
			}
			else if (s2 == 83)
			{
				d3++;
				d++;
				system("cls");
			}
		}
		else if (s1 == 80)
		{
			cout << "Player 2 chooses:";
			cin >> s2;
			if (s2 == 83)
			{
				d2++;
				d++;
				cout << "Player 2 win";
				Sleep(2000);
				system("cls");

			}
			else if (s2 == 82)
			{
				d1++;
				d++;
				cout << "Player 1 win";
				Sleep(2000);
				system("cls");
			}
			else if (s2 == 80)
			{
				d3++;
				d++;
				system("cls");
			}
		}
		int chon;
		cout << "Chon 1 de tiep tuc\n";
		cout << "Chon 2 de dung lai\n";
		cin >> chon;
		if (chon == 1)
		{
			goto X;
		}
		if (chon == 2)
		{
			cout << "Point player 1:" << d1 << endl;
			cout << "Point player 2:" << d2 << endl;
			cout << "number of times two teams draw:" << d3 << endl;
			cout << "battle number:" << d << endl;
			break;
		}
	}
}

