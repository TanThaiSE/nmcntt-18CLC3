///ID: 18127204
///Name: Thai Nhat Tan
///Ex81: Solve quadratic equation ax2 + bx + c = 0
#include<stdio.h>
#include"Ham.h"
#include<iostream>
using namespace std;
int main()
{
	double a, b, c, x1, x2;
	cout << "Nhap a,b,c:";	cin >> a >> b >> c;
	if (solveQuadratic(a, b, c, x1, x2) == 1)
	{
		cout << x1;
	}
	else if (solveQuadratic(a, b, c, x1, x2) == 2)
	{
		printf("Phuong trinh vo so nghiem\n");
	}
	else if (solveQuadratic(a, b, c, x1, x2) == 3)
	{
		printf("Phuong trinh vo nghiem\n");
	}
	else if (solveQuadratic(a, b, c, x1, x2) == 4)
	{
		printf("Phuong trinh vo nghiem\n");
	}
	else if (solveQuadratic(a, b, c, x1, x2) == 5)
	{
		cout << "phuong trinh co nghiem kep:x1=x2=" << x1;
	}
	else if (solveQuadratic(a, b, c, x1, x2) == 6)
	{
		cout << "phuong trinh co 2 nghiem x1=" << x1 << "\nx2=" << x2 << "";
	}
	return 0;
}