#ifndef _HAM_H_
#define _HAM_H_
int solveQuadratic(double a, double b, double c, double &x1, double &x2);
#endif
