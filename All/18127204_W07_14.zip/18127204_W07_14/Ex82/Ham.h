#ifndef _HAM_H_
#define _HAM_H_
void tomorrow(int day1, int month1, int year1, int &day2, int &month2, int &year2);
#endif