///ID: 18127204
///Name: Thai Nhat Tan
///Ex82: find next day (tomorrow)
#include<stdio.h>
#include"Ham.h"
int main()
{
	int day1, month1, year1, day2, month2, year2;
	printf("Enter day1-month1-year1:");	scanf_s("%d%d%d", &day1, &month1, &year1);
	tomorrow(day1, month1, year1, day2, month2, year2);
	return 0;
}