#include<stdio.h>
#include"Ham.h"
void tomorrow(int day1, int month1, int year1, int &day2, int &month2, int &year2)
{
	int n = month1 % 2;
	if ((day1 >= 1 && day1 <= 31) && month1 <= 7 && n == 1)
	{
		if (day1 == 31)
		{
			day2 = 1;
			month2 = month1 + 1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
		else
		{
			day2 = day1 + 1;
			month2 = month1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
	}
	else if ((day1 >= 1 && day1 <= 30) && month1 <= 7 && month1 != 2 && n == 0)
	{
		if (day1 == 30)
		{
			day2 = 1;
			month2 = month1 + 1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
		else if((day1 >= 1 && day1 < 30) && month1 <= 7 && month1 != 2 && n == 0)
		{
			day2 = day1 + 1;
			month2 = month1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
	}
	else if ((day1 >= 1 && day1 <= 30) && month1 > 7 && n == 1)
	{
		if (day1 == 30)
		{
			day2 = 1;
			month2 = month1 + 1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
		else if ((day1 >= 1 && day1 < 30) && month1 > 7 && n == 1)
		{
			day2 = day1 + 1;
			month2 = month1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
	}
	else if ((day1 >= 1 && day1 <= 31) && month1 > 7 && n == 0)
	{
		if (day1 == 31 && month1 == 12)
		{
			day2 = 1;
			month2 = 1;
			year2 = year1 + 1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
		else if ((day1 >= 1 && day1 < 31) && month1 > 7 && n == 0)
		{
			day2 = day1 + 1;
			month2 = month1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
	}
	else if (((year1 % 4 == 0 && year1 % 100 != 0) || year1 % 400 == 0) && month1 == 2)
	{
		if (day1 >= 1 && day1 < 29)
		{
			day2 = day1 + 1;
			month2 = month1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
		else if (day1 == 29)
		{
			day2 = 1;
			month2 = 3;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
	}
	else if ((year1 % 4 != 0 || year1 % 400 != 0) && month1 == 2)
	{
		if (day1 >= 1 && day1 < 28)
		{
			day2 = day1 + 1;
			month2 = month1;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
		else if (day1 == 28)
		{
			day2 = 1;
			month2 = 3;
			year2 = year1;
			printf("day2-month2-year2:%d  %d  %d", day2, month2, year2);
		}
	}
}