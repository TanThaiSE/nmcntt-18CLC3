#include<stdio.h>
#include"Ham.h"
float giatri(int n,float x)
{
	int m = 1;
	float s = 0;
	float t = 1;
	for (int i = 1; i <= n; i++)
	{
		m = m * i;
		t = t * x;
		s = s + 1.0*t / m;
	}
	return s;
}