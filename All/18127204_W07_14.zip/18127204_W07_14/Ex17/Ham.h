#ifndef _HAM_H_
#define _HAM_H_
float giatri(int n, float x);
#endif 
