///ID: 18127204
///Name: Thai Nhat Tan
///Ex17: Tinh S(x)
#include<stdio.h>
#include"Ham.h"
int main()
{
	int n; float x, y;
	printf("Nhap n:");	scanf_s("%d", &n);
	printf("Nhap x:");	scanf_s("%f", &x);
	y = giatri(n, x);
	printf("%f", y);
	return 0;
}