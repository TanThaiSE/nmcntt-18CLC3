#include<stdio.h>
#include<math.h>
#include"Ham.h"
float tinhtong(int n)
{
	float s = 0, t;
	for (int i = 1; i <= n; i++)
	{
		t = 1.0 / (i + 1);
		s = float(pow(s + i, t));
	}
	return s;

}
