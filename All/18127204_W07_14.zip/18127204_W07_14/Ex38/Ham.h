#ifndef _HAM_H_
#define _HAM_H_
float tinhtong(int n);
#endif
