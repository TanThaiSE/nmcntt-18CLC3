///ID: 18127204
///Name: Thai Nhat Tan
///Ex30,31,32: kiem tra so#include
#include<stdio.h>
#include<math.h>
#include"Ham.h"
int main()
{
	int n;
	float y;
	printf("Nhap n:");	scanf_s("%d", &n);
	y = tinhtong(n);
	printf("Ket qua la:%f", y);
	return 0;
}