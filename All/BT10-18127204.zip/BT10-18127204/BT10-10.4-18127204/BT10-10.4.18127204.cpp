#include<stdio.h>
#include<string>
#include<iostream>
using namespace std;
int main()
{
	char s[1000];
	FILE *f1;
	fopen_s(&f1, "C:\\Users\\TH.28.08.2018\\Downloads\\18127204_NMLT_LT\\BT10-18127204\\BT10-10.4-18127204\\INPUT.txt", "r");
		fgets(s, 1000, f1);
	fclose(f1);
	int k;
	printf("Nhap k:");	scanf_s("%d", &k);
	for (int i = 0; i < strlen(s); i++)
	{
		if (s[i] >= 65 && s[i] <= 90)
		{
			s[i] = s[i] + k;
			if (s[i] > 90)
			{
				s[i] = s[i] - 90 + 64;
			}
		}
	}

	FILE *f2;
	fopen_s(&f2, "C:\\Users\\TH.28.08.2018\\Downloads\\18127204_NMLT_LT\\BT10-18127204\\BT10-10.4-18127204\\OUTPUT.txt", "w");
	fputs(s, f2);
	fclose(f2);
	for (int i = 0; i < strlen(s); i++)
	{
		if (s[i] >= 65 && s[i] <= 90)
		{
			s[i] = s[i] - k;
			if (s[i] < 65)
			{
				s[i] = s[i] - 64 + 90;
			}
		}
	}
	FILE *f3;
	fopen_s(&f3, "C:\\Users\\TH.28.08.2018\\Downloads\\18127204_NMLT_LT\\BT10-18127204\\BT10-10.4-18127204\\OUTPUT1.txt", "w");
	fputs(s, f3);
	fclose(f3);
	return 0;
}

