#include<stdio.h>
int main()
{
	int n, a = 0, b = 0, x, y, i=0, k=0;
	printf("Nhap N=");		scanf_s("%d", &n);
	b = n;
	while (b > 0)
	{
		a = a * 10 + b % 10;
		b /= 10;
	}
	if (a == n)
		printf("Cac chu so doi xung.\n");

	else
		printf("Cac chu so khong doi xung.\n");
	x = n % 10;
	n = n / 10;
	while (n != 0)
	{
		y = n % 10;
		if (x > y) i = 1;
		if (y > x) k = 1;
		if (x == y) return printf("cac chu so khong giam dan tu hang don vi\n");
		x = y; n = n / 10;
	}
	if (i == 1 && k == 1) printf("cac chu so khong giam dan tu hang don vi\n");
	if (i == 1 && k == 0) printf("cac chu so  giam dan tu hang don vi\n");
	if (i == 0 && k == 1) printf("cac chu so khong giam dan tu hang don vi\n");
	if (i == 0 && k == 0) printf("cac chu so khong giam dan tu hang don vi\n");
	return 0;
}