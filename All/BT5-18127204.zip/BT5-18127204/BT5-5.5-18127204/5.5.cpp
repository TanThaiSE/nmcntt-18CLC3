#include<stdio.h>
int main()
{
	int n, k, i;
	int a = 0;
	printf("Nhap N=");	scanf_s("%d", &n);
	for (k = 2; k <= n; k++)
	{
		int dem = 0;
		for (i = 2; i < k; i++)
			if (k%i == 0) dem++;
		if (dem == 0)
		{
			a = a + 1;
			printf("#%d=%d\n", a, k);
		}
			
	}
	printf("Co tat ca %d so nguyen to",a);
		return 0;
}