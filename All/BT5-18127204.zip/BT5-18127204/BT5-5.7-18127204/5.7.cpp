#include<stdio.h>
int main()
{
	char std;
	printf("So dien thoai: ");
	while (std = getchar())
	{
		switch (std)
		{
		case '0':
			printf("khong ");
			break;
		case '1':
			printf("mot ");
			break;
		case '2':
			printf("hai ");
			break;
		case '3':
			printf("ba ");
			break;
		case '4':
			printf("bon ");
			break;
		case '5':
			printf("nam ");
			break;
		case '6':
			printf("sau ");
			break;
		case '7':
			printf("bay ");
			break;
		case '8':
			printf("tam ");
			break;
		case '9':
			printf("chin ");
			break;
		}
	}
return 0;
}