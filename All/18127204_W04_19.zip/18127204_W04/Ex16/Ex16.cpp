///ID:18127204
///Name: Thai Nhat Tan
///Ex16: Tinh S(n)
#include<stdio.h>
#include<math.h>
int main()
{
	float m, a, t, i;
	float s, b;
	printf("Nhap n:");
	scanf_s("%f", &a);
	printf("Nhap x:");
	scanf_s("%f", &b);
	t = 1;
	m = 0;
	s = 0;
	for (i = 1; i <= a; i += 1)
	{
		t = t * b;
		m = m + i;
		s = s + 1.0*(t / m);
	}
	printf("S(n)=%0.2f", s);
	return 0;
}