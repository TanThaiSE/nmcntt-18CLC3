///ID:18127204
///Name: Thai Nhat Tan
///Ex12: Tinh S(n)
#include<stdio.h>
int main()
{
	int a;
	float b, i, s, t;
	printf("Nhap n:");
	scanf_s("%d", &a);
	printf("Nhap x:");
	scanf_s("%f", &b);
	s = 0;
	t = 1;
	for (i = 1; i <= a; i += 1)
	{
		t = t*b;
		s = s + 1.0*t;
	}
	printf("S(n)=%0.2f", s);
	return 0;
}