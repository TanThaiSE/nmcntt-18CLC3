///ID:18127204
///Name: Thai Nhat Tan
///Ex08: Tinh S(n)
#include<stdio.h>
int main()
{
	int a;
	float s, i;
	printf("Nhap n:");
	scanf_s("%d", &a);
	s = 0;
	for (i = 0; i <= a; i = i + 1)
	{
		s = s + 1.0*((2 * i + 1) / (2 * i + 2));
	}
	printf("S(n)=%0.2f", s);
	return 0;
}