///ID:18127204
///Name: Thai Nhat Tan
///Ex76: Kiem tra so nguyen
#include<stdio.h>
int main()
{
	int n, i, b, a;
	printf("Nhap N:");
	scanf_s("%d", &n);
	b = 1;
	a = 0;
	for (i = 1; b <= n; i += 1)
	{
		b = b * 3;
		if (b == n)
		{
			a = a + 1;
		}
	}
	if (a == 1)
		printf("%d la so nguyen co dang 3^%d", n, i - 2);
	else
		printf("%d khong la so nguyen co dang 3^k", n);
	return 0;
}