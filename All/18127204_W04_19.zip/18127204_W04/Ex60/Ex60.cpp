///ID:18127204
///Name: Thai Nhat Tan
///Ex60: kiem tra so tang dan tu trai sang phai
#include<stdio.h>
int main()
{
	int n, c, d, a, b;
	printf("Nhap so nguyen duong N:");
	scanf_s("%d", &n);
	c = 0;
	d = 0;
	while (n > 0)
	{
		a = n % 10;
		n = n / 10;
		b = n % 10;
		if (b < a)
		{
			c += 1;
		}
		d += 1;
	}
	if (c == d)
		printf(" Cac chu so tang dan tu trai sang phai");
	else
		printf("Cac chu so khong tang dan tu trai sang phai");
	return 0;
}