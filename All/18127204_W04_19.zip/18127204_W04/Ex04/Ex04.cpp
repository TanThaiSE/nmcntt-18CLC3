///ID:18127204
///Name: Thai Nhat Tan
///Ex04: Tinh S(n)
#include<stdio.h>
int main()
{
	int a;
	float s, i;
	printf("Nhap n:");
	scanf_s("%d", &a);
	s = 0;
	for (i = 1; i <= a; i += 1)
	{
		s = s + 1.0 * 1 / 2 * (1 / i);
	}
	printf("S(n)= %0.2f", s);
	return 0;
}