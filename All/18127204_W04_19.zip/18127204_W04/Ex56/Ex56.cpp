///ID:18127204
///Name: Thai Nhat Tan
///Ex56: Tim chu so nho nhat
#include<stdio.h>
int main()
{
	int n, a, b, c;
	printf("Nhap so nguyen duong N:");
	scanf_s("%d", &n);
	b = 0;
	c = 0;
	while (n > 0)
	{
		a = n % 10;
		if (a % 2 == 1)
		{
			b += 1;
		}
			n = n / 10;
			c += 1;
	}
	if (b == c)
		printf("Toan chu so le");
	else
		printf("Khong toan chu so le");
		return 0;
}