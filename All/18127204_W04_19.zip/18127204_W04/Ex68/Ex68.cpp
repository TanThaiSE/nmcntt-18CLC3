///ID: 18127204
///Name: Thai Nhat Tan
///Ex68: Tinh s(x,n)
#include<stdio.h>
int main()
{
	int i, a, n;
	float x, m, s;
	printf("Nhap x:");
	scanf_s("%f", &x);
	printf("Nhap n:");
	scanf_s("%d", &n);
	m = 1;
	s = 0;
	a = 1;
	for (i = 1; i <= n; i += 1)
	{
		a = a * (-1);
		m = m * x*x;
		s = s + 1.0*a*m;
	}
	printf("s(x,n)=%0.2f", s);
	return 0;
}