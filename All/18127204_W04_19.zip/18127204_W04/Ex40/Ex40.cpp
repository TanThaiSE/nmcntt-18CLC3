///ID:18127204
///Name: Thai Nhat Tan
///Ex40: Tinh S(n)
#include<stdio.h>
#include<math.h>
int main()
{
	int n, i;
	float x, s, b;
	printf("Nhap x:");
	scanf_s("%f", &x);
	printf("Nhap N:");
	scanf_s("%d", &n);
	s = 0;
	b = 1;
	for (i = 1; i <= n; i += 1)
	{
		b = b * x;
		s = sqrt(b + s);
	}
	printf("S(n)=%0.2f", s);
	return 0;
}