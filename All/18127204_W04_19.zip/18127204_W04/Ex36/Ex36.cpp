///ID:18127204
///Name: Thai Nhat Tan
///Ex36: Tinh S(n)
#include<stdio.h>
#include<math.h>
int main()
{
	int n, m, i;
	float s;
	printf("Nhap N:");
	scanf_s("%d", &n);
	s = 0;
	m = 1;
	for (i = 1; i <= n; i += 1)
	{
		m = m * i;
		s = sqrt(m + s);
	}
	printf("S(n)=%0.2f", s);
	return 0;
}
