///ID:18127204
///Name: Thai Nhat Tan
///Ex44: Tinh tong cac chu so
#include<stdio.h>
int main()
{
	int n, a, s;
	printf("Nhap so nguyen duong N:");
	scanf_s("%d", &n);
	s = 0;
	while (n > 0)
	{
		a = n % 10;
		n = n / 10;
		s = s + a;
	}
	printf("Tong cac chu so la:%d", s);
	return 0;
}