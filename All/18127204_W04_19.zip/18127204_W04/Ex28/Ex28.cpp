///ID:18127204
///Name: Thai Nhat Tan
///Ex28: Tinh tong cac uoc nho hon chinh no
#include<stdio.h>
int main()
{
	int n, i, s;
	printf("Nhap so nguyen duong N:");
	scanf_s("%d", &n);
	s = 0;
	for (i = 1; i < n; i += 1)
	{
		if ((n%i == 0))
		{
			s = s + i;
		}
	}
	printf("Tong uoc so nho hon chinh no: %d", s);
	return 0;
}