///ID:18127204
///Name: Thai Nhat Tan
///Ex72: Tinh s(x,n)
#include<stdio.h>
int main()
{
	int n, m, c, i;
	float x, s, b;
	printf("Nhap x:");
	scanf_s("%f", &x);
	printf("Nhap n:");
	scanf_s("%d", &n);
	s = 0;
	b = 1;
	m = 1;
	c = 1;
	for (i = 1; i <= n; i += 1)
	{
		m = m * i;
		c = c * (-1);
		b = b * x;
		s = s + 1.0*(c*b / m);
	}
	printf("s(x,n)=%f", s);
	return 0;
}