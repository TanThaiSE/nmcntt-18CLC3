///ID:18127204
///Name: Thai Nhat Tan
///Ex48: Tinh tich cac chu so le
#include<stdio.h>
int main()
{
	int n, a, s;
	printf("Nhap so nguyen duong N:");
	scanf_s("%d", &n);
	s = 1;
	while (n > 0)
	{
		a = n % 10;
		n = n / 10;
		if (a % 2 == 1)
		{
			s = s * a;
		}
	}
	printf("Tich cac chu so le la:%d", s);
	return 0;
}