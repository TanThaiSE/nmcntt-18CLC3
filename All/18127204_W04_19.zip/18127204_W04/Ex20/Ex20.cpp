///ID:18127204
///Name: Thai Nhat Tan
///Ex20: Tinh uoc so
#include <stdio.h>
int main()
{
	int n, i;
		printf("Nhap N = ");
		scanf_s("%d", &n);
	printf("Cac uoc so cua %d la :\n", n);
	for (i = 1; i <= n; i++)
		if ((n % i) == 0)
			printf("%d\n", i);
	return 0;
}