///ID:18127204
///Name: Thai Nhat Tan
///Ex52: Tim chu so nho nhat
#include<stdio.h>
int main()
{
	int n, a, b;
	printf("Nhap so nguyen duong N:");
	scanf_s("%d", &n);
	b = 9;
	while (n > 0)
	{
		a = n % 10;
		if (a < b)
		{
			b = a;
		}
		n = n / 10;
	}
	printf("Chu so nho nhat la:%d", b);
	return 0;
}