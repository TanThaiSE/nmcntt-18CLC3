///ID:18127204
///Name: Thai Nhat Tan
///Ex32: Kiem tra co phai la so chinh phuong hay khong
#include<stdio.h>
int main()
{
	int n, i, b;
	printf("Nhap so nguyen duong N:");
	scanf_s("%d", &n);
	b = 0;
	for (i = 1; i <= n; i += 1)
	{
		if (i*i == n)
		{
			b =1;
		}
	}
	if (b == 1)
		printf("%d la so chinh phuong", n);
	else
		printf("%d khong la so chinh phuong", n);
	return 0;
}