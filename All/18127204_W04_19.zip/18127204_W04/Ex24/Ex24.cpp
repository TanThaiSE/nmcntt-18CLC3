///ID:18127204
///Name: Thai Nhat Tan
///Ex24: Tinh uoc so le
#include<stdio.h>
int main()
{
	int n, i, d;
	printf("Nhap so nguyen duong N:");
	scanf_s("%d", &n);
	printf("Cac uoc so le cua %d la:", n);
	for (i = 1; i <= n; i += 1)
	{
		if ((d = n % i == 0))
		{
			if (i % 2 == 1)
				printf("%d\n", i);
		}
	}
	return 0;
}