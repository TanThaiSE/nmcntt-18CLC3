#include<iostream>
using namespace std;
int main()
{
	int n, h, s = 0;
	cin >> n >> h;
	for (int i = 0; i < n; ++i)
	{
		int a;  cin >> a;
		if (a <= h)
			s++;
		else {
			s++;
			s++;
		}
	}
	cout << s;
	return 0;
}