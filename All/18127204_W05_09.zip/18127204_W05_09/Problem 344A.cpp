#include<iostream>
using namespace std;
int main()
{
	int n, a, b, c = 0;
	cin >> n;
	cin >> a;
	for (int i = 1; i <= (n - 1); i++) {
		cin >> b;
		if (b != a)
		{
			c++;
			a = b;
		}
	}
	c = c + 1;
	cout << c << endl;
	return 0;

}