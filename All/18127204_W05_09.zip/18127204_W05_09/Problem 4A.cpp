#include <iostream>
using namespace std;
int main()
{
	int a;
	cin >> a;
	if (a % 2 == 0 && a > 2)
		cout << "YES\n";
	else
		cout << "NO\n";
	return 0;
}