#include<iostream>
using namespace std;
int main()
{
	int n;
	char a, b;
	int sf = 0, fs = 0;
	cin >> n;
	cin >> a;
	for (int i = 1; i < n; i++)
	{
		cin >> b;
		if (b != a)
		{
			if (b == 'S')
				sf++;
			else
				fs++;
			a = b;
		}
	}
	if (sf < fs) {
		cout << "YES" << "\n";
	}
	else {
		cout << "NO" << "\n";
	}
	return 0;
}