#include<stdio.h>
int main()
{
	int n, a, b, c;
	printf("");
	scanf("%d", &n);
	b = 0;
	c = n;
	while (n--)
	{
		printf("");
		scanf("%d", &a);
		if(a==0)
		{
			b++;
		}
	}
	if (c == 1 && a == 0)
		printf("NO\n");
	else if ((b == 1) || (c == 1 && a == 1))
		printf("YES\n");
	else 
		printf("NO\n");
	return 0;
}