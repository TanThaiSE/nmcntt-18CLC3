#include<stdio.h>
#include<math.h>
#include<iostream>
using namespace std;
int main()
{
	long long int m, n, a, tm, tn, sm, sn, sl;
	cin >> n >> m >> a;
	tn = n / a;
	tm = m / a;
	if (n%a != 0) sn = (tn + 1)*a; else sn = tn * a;
	if (m%a != 0) sm = (tm + 1)*a; else sm = tm * a;
	sl = (sn*sm) / (a*a);
	cout << sl;
	return 0;
}