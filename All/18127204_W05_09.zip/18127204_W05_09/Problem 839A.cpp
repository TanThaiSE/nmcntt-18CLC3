#include <iostream>
using namespace std;
int main()
{
	int n, k;
	cin >> n >> k;
	int arya = 0, bran = 0;
	int s = 0;
	for (int i = 0; i < n; ++i)
	{
		int b;
		cin >> b;
		if (b + arya >= 8)
		{
			bran += 8;
			arya += b - 8;
			++s;
		}
		else
		{
			bran += b + arya;
			arya = 0;
			++s;
		}
		if (bran >= k)
		{
			cout << s << "\n";
			return 0;
		}
	}

	if (bran < k)
	{
		cout << -1 << "\n";
	}
	return 0;
}