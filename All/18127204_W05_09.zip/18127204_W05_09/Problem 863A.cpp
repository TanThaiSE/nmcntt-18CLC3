#include<iostream>
using namespace std;
int main()
{
	long long int n, a = 0, b = 0;
	cin >> n;
	while (n % 10 == 0)
	{
		n /= 10;
		a = 0;
	}
	b = n;
	while (b > 0)
	{
		a = a * 10 + b % 10;
		b /= 10;
	}
	if (a == n)
		cout << "YES" << endl;
	else
		cout << "NO" << endl;
}