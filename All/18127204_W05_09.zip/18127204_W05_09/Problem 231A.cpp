#include<iostream>
using namespace std;
int main()
{
	int p, v, t, s = 0, n;
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> p >> v >> t;
		if (p + v + t >= 2)
		{
			s++;
		}
	}
	cout << s << endl;
	return 0;
}