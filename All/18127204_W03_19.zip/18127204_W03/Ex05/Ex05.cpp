///ID: 18127204
///Name: Thai Nhat Tan
///Ex05: diem so cua sinh vien
#include<stdio.h>
int main()
{
	float a, b, c, d;
	int e;
	printf("Thuc hanh:");
	scanf_s("%f", &a);
	printf("Bai tap:");
	scanf_s("%f", &b);
	printf("Thi ly thuyet:");
	scanf_s("%f", &c);
	printf("Copy:");
	scanf_s("%d", &e);
	d = a * 0.3 + b * 0.3 + c * 0.4;
	if (d < 5)
		printf("Failed");
	else 
	{
			if ((a == 0) || (b == 0) || (c == 0) || (e != 0))
			{	
				printf("0.0=>Failed");
			}
			else
			{
				printf("Diem tong:%0.2f=>Passed", d);
			}
	}
	return 0;
}