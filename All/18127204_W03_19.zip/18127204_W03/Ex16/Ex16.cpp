///ID: 18127204
///Name: Thai Nhat Tan
///Ex16: Tinh tien thue phong karaoke
#include<stdio.h>
#include<math.h>
int main()
{
	int sd, thoidiem, thu, vip, tien, a, b;
	do
	{
		printf("Thu(CN=8):");
		scanf_s("%d", &thu);
	} while (thu < 2 || thu >8);
	do
	{
		printf("Gio bat dau thue:");
		scanf_s("%d", &a);
		printf("Gio ket thuc thue:");
		scanf_s("%d", &b);
		sd = fabs(b - a);
	} while (sd < 0 || sd>10);
	printf("Phong VIP(neu khong chon nhan 0):");
	scanf_s("%d", &vip);
	do
	{
		printf("Thoi diem: nhap 1 : la tu 10:00 -> 18:00, nhap 2 : la sau 18:00:");
		scanf_s("%d", &thoidiem);
	} while (thoidiem < 1 || thoidiem>2);

	if (thu <= 6)
	{
		if (thoidiem == 1)
		{
			if (vip != 0)
			{
				tien = 100000 * sd;
			}
			else
			{
				tien = 80000 * sd;
			}
		}
		else
		{
			if (vip != 0)
			{
				tien = 300000 * sd;
			}
			else
			{
				tien = 200000 * sd;
			}
		}
	}
	else
	{
		if (vip != 0)
		{
			tien = 400000 * sd;
		}
		else
		{
			tien = 200000 * sd;
		}
	}
	printf("Tien:%d", tien);
	return 0;
}