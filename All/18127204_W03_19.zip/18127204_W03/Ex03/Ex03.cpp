///ID: 18127204
///Name: Thai Nhat Tan
///Ex03: tim so lon hon giua 2 so nguyen
#include<stdio.h>
int main()
{
	int a, b;
	printf("");
	scanf_s("%d%d", &a, &b);
	if (a > b)
		printf("%d", a);
	else
		printf("%d", b);
	return 0;
}