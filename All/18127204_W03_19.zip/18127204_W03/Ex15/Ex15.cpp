///ID: 18127204
///Name: Thai Nhat Tan
///Ex15: xac dinh tam giac
#include<stdio.h>
#include<math.h>
int main()
{
	float a, b, c;
	printf(""); scanf_s("%f%f%f", &a, &b, &c);
	if ((a + b) > c && (fabs(a - b)) < c && (b + c) > a && (fabs(b - c)) < a && (c + a) > b && (fabs(c - a)) < b)
	{
		printf("is triangular edge\n");
		{
			if ((a == b) && (b == c) && (c == a))
				printf("equilateral triangle\n");
			else if ((a == b) || (a == c) || (b == c))
				printf("isosceles triangle\n");
			else if ((a*a == b * b + c * c) && (b == c) || (b*b == c * c + a * a) && (c == a) || (c*c == a * a + b * b) && (a == b))
				printf("right triangle weight\n");
			else if ((a*a == b * b + c * c) || (b*b == c * c + a * a) || (c*c == a * a + b * b))
				printf("triangle square\n");
			else if ((a + b) > c && (fabs(a - b)) < c && (b + c) > a && (fabs(b - c)) < a && (c + a) > b && (fabs(c - a)) < b)
				printf("normal triangle\n");
		}
	}
	else 
			printf("is not triangular edge\n");

	return 0;
}