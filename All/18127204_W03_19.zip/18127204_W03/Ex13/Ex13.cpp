///ID: 18127204
///Name: Thai Nhat Tan
///Ex13: xac dinh nam nhuan
#include<stdio.h>
int main()
{
	int a;
	printf("Enter year:");
	scanf_s("%d", &a);
	if (a % 4 == 0 && a % 100 != 0)
		printf("Leap Year");
	else if (a % 400 == 0)
		printf("Leap Year");
	else
		printf("Not the leap year");

	return 0;
}