///ID: 18127204
///Name: Thai Nhat Tan
///Ex02: tim so nho hon giua 2 so nguyen
#include<stdio.h>
int main()
{
	int a, b;
	printf("");
	scanf_s("%d%d", &a, &b);
	
	if (a > b)
		printf("%d", b);
	else
		printf("%d", a);
	return 0;
}