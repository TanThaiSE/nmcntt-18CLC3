///ID: 18127204
///Name: Thai Nhat Tan
///Ex07: thang diem chu ABCDF cua sv
#include<stdio.h>
int main()
{
	float x;
	printf("Diem trung binh:");
	scanf_s("%f", &x);
	if (x >= 8.5&&x <= 10)
		printf("A",x);
	else
		if (x >= 7 && x <= 8.4)
			printf("B");
		else
			if (x >= 5.5&&x <= 6.9)
				printf("C");
			else
				if (x >= 4 && x <= 5.4)
					printf("D");
				else
						printf("F");
	
	return 0;
}