///ID: 18127204
///Name: Thai Nhat Tan
///Ex14: so ngay trong thang
#include<stdio.h>
int main()
{
	int a, b;
	printf("nhap vao thang va nam");
	scanf_s("%d%d", &a, &b);
	switch (a)
	{
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		printf("so ngay la 31");
		break;
	case 4:
	case 6:
	case 9:
	case 11:
		printf("so ngay la 30");
		break;
	case 2:
		if (b % 4 == 0 && b % 100 != 0)
			printf("so ngay la 29");
		else if (b % 400 == 0)
			printf("so ngay la 29");
		else
			printf("so ngay la 28");
		break;
	defaul: printf("Khong ton tai");
		break;
	}

	return 0;
}