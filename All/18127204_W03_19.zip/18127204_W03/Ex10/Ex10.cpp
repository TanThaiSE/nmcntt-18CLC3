///ID: 18127204
///Name: Thai Nhat Tan
///Ex10: Giai phuong trinh ax + b = 0
#include<stdio.h>
#include<math.h>
int main()
{
	float a, b;
	printf("a:");
	scanf_s("%f", &a);
	printf("b:");
	scanf_s("%f", &b);
	if (a != 0)
		printf("%f", -b * 1.0 / a);
	else
	{
		if (b == 0)
		{
			printf("Vo so nghiem");
		}
		else
		{			
				printf("vo nghiem");
		}
	}
	return 0;
}