///ID: 18127204
///Name: Thai Nhat Tan
///Ex11: Giai phuong trinh ax2 + bx + c = 0
#include<stdio.h>
#include<math.h>
#include <conio.h>
int main()
{
	float a, b, c, d, x1, x2, x3;
	printf("a:"); 
	scanf_s("%f", &a);
	printf("b:"); 
	scanf_s("%f", &b);
	printf("c:"); 
	scanf_s("%f", &c);
	if (a == 0)
	{
		if (b == 0)
		{
			if (c == 0)
				printf("vo so nghiem");
			else if (c != 0)
				printf("vo nghiem");
		}
		else
		{
			if (c != 0)
				x3 = -c * 1.0 / b;
			printf("%f", x3);
		}
	}
	else if (a!=0)
	{
		d = b * b - 4 * a*c;
			if (d < 0)
				printf("phuong trinh vo nghiem");
			else if (d > 0)
			{
				x1 = (-b - sqrt(d)) / (2 * a);
				x2 = (-b + sqrt(d)) / (2 * a);
				printf("nghiem phuong trinh la: %f\n%f\n", x1, x2);
			}
			else if (d = 0)
				printf("phuong trinh co nghiem kep:%f", -b * 1.0 / (2 * a));
	}
return 0;
}