///ID: 18127204
///Name: Thai Nhat Tan
///Ex18: Tinh tien dien
#include<stdio.h>
int main()
{
	int a, b, c;
	float s1, s2, s3, s4, s5, s6, s7;
	do
	{
		printf("Nhap so dien thang truoc:");
		scanf_s("%d", &a);
		printf("Nhap so dien thang nay:");
		scanf_s("%d", &b);
	} while (a > b || a < 0 || b < 0);
		c = b - a;				
			if (c >= 401)
			{
				s6 = (1484 * 50 + 1533 * 50 + 1786 * 100 + 2242 * 100 + 2503 * 400 + 2587 * (c - 400))*1.1;
				printf("Tien dien phai tra:%f", s6);
			}
			else
			{
				if (c >= 301)
				{
					s5 = (1484 * 50 + 1533 * 50 + 1786 * 100 + 2242 * 100 + 2503 * (c - 300))*1.1;
					printf("Tien dien phai tra:%f", s5);
				}
				else
				{
					if (c >= 201)
					{
						s4 = (1484 * 50 + 1533 * 50 + 1786 * 100 + 2242 * (c - 200))*1.1;
						printf("Tien dien phai tra:%f", s4);
					}
					else
					{
						if (c >= 101)
						{
							s3 = (1484 * 50 + 1533 * 50 + 1786 * (c - 100))*1.1;
							printf("Tien dien phai tra:%f", s3);
						}
						else
						{
							if (c >= 51)
							{
								s2 = (1484 * 50 + 1533 * (c - 50))*1.1;
								printf("Tien dien phai tra:%f", s2);
							}
							else
							{
								if (c > 0)
								{
									s1 = (c * 1484)*1.1;
									printf("Tien dien phai tra:%f", s1);
								}
								else
								{
									printf("Tien dien phai tra:%f",1484*1.1);
								}
							}
						}
					}
				}
			}
		
	return 0;
}