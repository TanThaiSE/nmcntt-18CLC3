///ID: 18127204
///Name: Thai Nhat Tan
///Ex19: Tinh tien nuoc
#include<stdio.h>
int main()
{
	int a, b, c;
	float s1, s2, s3;
	do
	{
		printf("Nhap vao chi so nuoc thang truoc:");
		scanf_s("%d", &a);
		printf("Nhap vao chi so nuoc thang sau:");
		scanf_s("%d", &b);
	} while (a < 0 || b<0 || a>b);
	c = b - a;
	if (c > 6)
	{
		s3 = (4 * 3300 + 2 * 5200 + (c - 6) * 7000)*1.1;
		printf("Tien nuoc phai tra:%f", s3);
	}
	else
	{
		if (c > 4)
		{
			s2 = (4 * 3300 + (c - 4) * 5200)*1.1;
			printf("Tien nuoc phai tra:%f", s2);
		}
		else
		{
			if (c > 0)
			{
				s1 = (3300 * c)*1.1;
				printf("Tien nuoc phai tra:%f", s1);
			}
			else
			{
				printf("Tien nuoc phai tra:%f", 3300 * 1.1);
			}
		}
	}
	return 0;
}