///ID: 18127204
///Name: Thai Nhat Tan
///Ex08: Doc so
#include<stdio.h>
int main()
{
	int a;
	printf("Nhap so:");
	scanf_s("%d", &a);
	switch (a)
	{
	case 0: printf("khong");
		break;
	case 1: printf("mot");
		break;
	case 2: printf("hai");
		break;
	case 3: printf("ba");
		break;
	case 4: printf("bon");
		break;
	case 5: printf("nam");
		break;
	case 6: printf("sau");
		break;
	case 7: printf("bay");
		break;
	case 8: printf("tam");
		break;
	case 9: printf("chin");
		break;
	default: printf("Khong doc duoc");
		break;
	}
	return 0;
}