///ID: 18127204
///Name: Thai Nhat Tan
///Ex09: Chuyen chu thuong thanh chu hoa va nguoc lai
#include<stdio.h>
int main()
{
	char ch;
	printf("Nhap vao mot chu cai:");
	scanf_s("%c", &ch);
	if (ch >= 'A'&&ch <= 'Z')
	{
		ch = ch + 32;
		printf("%c", ch);
	}
	else
	{
		if (ch >= 'a'&&ch <= 'z')
			ch = ch - 32;
		printf("%c", ch);
	}
	return 0;
}