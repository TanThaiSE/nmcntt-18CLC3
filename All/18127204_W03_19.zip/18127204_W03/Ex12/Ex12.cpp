///ID: 18127204
///Name: Thai Nhat Tan
///Ex12: Tien di taxi
#include<stdio.h>
#include<math.h>
int main()
{
	int x, s1, s2, s3, s4;
	int a, b, c, e;
	float d;

	printf("");
	scanf_s("%d", &x);
	a = 15000 * 1;
	b = 4 * 13500;
	c = (x - 5) * 11000;
	d = 0.9;
	e = (x - 1) * 13500;
	if (x > 12)
	{
		s4 = (15000 * 1 + 4 * 13500 + (x - 5) * 11000)*0.9;
		printf("(%d+%d+%d)*%0.1f=%d", a, b, c, d, s4);
	}
	else
	{
		if (x > 5)
		{
			s3 = 15000 * 1 + 4 * 13500 + (x - 5) * 11000;
			printf("%d+%d+%d=%d", a, b, c, s3);
		}
		else
		{
			if (x >= 2)
			{
				s2 = 15000 * 1 + (x - 1) * 13500;
				printf("%d+%d=%d", a, e, s2);
			}
			else
			{
				if (x > 0)
					s1 = 15000 * x;
				printf("%d",s1);
			}
		}
	}
	return 0;
}