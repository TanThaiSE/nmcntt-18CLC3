///ID: 18127204
///Name: Thai Nhat Tan
///Ex06: xep loai hoc luc cua sv cao dang, dai hoc
#include<stdio.h>
int main()
{
	float a;
	printf("Nhap diem trung binh:");
	scanf_s("%f",&a);
	if (a >= 9 && a <= 10)
		printf("Outstanding");
	else
		if (a >= 8 && a < 9)
			printf("Good");
		else
			if (a >= 7 && a < 8)
				printf("Rather");
			else
				if (a >= 6 && a < 7)
					printf("Above average");
				else
					if (a >= 5 && a < 6)
						printf("Medium");
					else
						if (a >= 4 && a < 5)
							printf("Weak");
						else
								printf("Least");
	return 0;
}