///ID: 18127204
///Name: Thai Nhat Tan
///Ex04: diem so cua sinh vien
#include<stdio.h>
int main()
{
	float a, b, c, d;
	printf("Thuc hanh:");
	scanf_s("%f", &a);
	printf("Bai tap:");
	scanf_s("%f", &b);
	printf("Thi ly thuyet:");
	scanf_s("%f", &c);
	d = (a*0.3 + b * 0.3 + c * 0.4);
	if (d >= 5)
		printf("Diem tong:%0.2f=>Passed", d);
	else
		printf("Failed");
	return 0;
}