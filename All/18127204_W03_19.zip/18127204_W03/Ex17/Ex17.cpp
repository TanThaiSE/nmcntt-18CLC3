///ID: 18127204
///Name: Thai Nhat Tan
///Ex17: Tinh gia ve xem phim
#include<stdio.h>
int main()
{
	int a;
	float b;
	printf("Nhap vao thu (neu la CN thi nhap la 8):");
	scanf_s("%d", &a);
	printf("Nhap thoi gian xem:");
	scanf_s("%f", &b);
	if (a <= 8 && a >= 2)
	{
		if (a == 3)
			printf_s("Gia ve:50000 VND");
		else
		{
			if (a == 2 || a == 4 || a == 5)
			{
				if (b >= 0 && b < 17)
					printf("Gia ve:60000 VND");
				else if (b >= 17 && b < 24)
					printf("Gia ve:70000 VND");
			}
			else
			{
				if (b >= 0 && b < 17)
					printf("Gia ve:75000VND");
				else if (b >= 17 && b < 24)
					printf("Gia ve:80000VND");
			}
		}
	}
	else
		printf("Khong ton tai ngay%d", &a);
	return 0;
}